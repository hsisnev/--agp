"""Package v1.7.6 only after a native Zygisk binary has been built and verified."""
import argparse
import hashlib
from pathlib import Path
import re
import struct
import subprocess
import zipfile

project = Path(__file__).resolve().parent
source = project / 'module-v1.7.6-zygisk'
parser = argparse.ArgumentParser()
parser.add_argument('library', type=Path)
parser.add_argument('--readelf', default='readelf')
parser.add_argument('--out', type=Path, default=project.parent / '破-AGP_v1.7.6_Zygisk.zip')
args = parser.parse_args()
if not args.library.is_file():
    parser.error('build the Android arm64-v8a.so before packaging')

library = args.library.read_bytes()
if not (library[:6] == b'\x7fELF\x02\x01' and struct.unpack_from('<HH', library, 16) == (3, 183)
        and b'Lorg/poagp/zygisk/ThermalHook;' in library):
    raise SystemExit('expected a dynamically loadable ARM64 ELF with the hook DEX embedded')

symbols = subprocess.check_output([args.readelf, '-W', '--dyn-syms', str(args.library)], text=True)
if not re.search(r'\bFUNC\s+GLOBAL\s+DEFAULT\s+\d+\s+zygisk_module_entry\s*$', symbols, re.MULTILINE):
    raise SystemExit('Zygisk entry point is absent from the dynamic symbol table')
dynamic = subprocess.check_output([args.readelf, '-d', str(args.library)], text=True)
deps = set(re.findall(r'Shared library: \[([^\]]+)\]', dynamic))
if deps - {'libc.so', 'libdl.so', 'libm.so', 'liblog.so'}:
    raise SystemExit(f'unexpected runtime library dependency: {sorted(deps)}')

entries = {}
for path in sorted(source.rglob('*')):
    relative = path.relative_to(source)
    if path.is_file() and relative.parts[0] not in ('zygisk-src', 'tests'):
        if path.is_symlink() or path.suffix == '.apk' or path.name == 'action.sh':
            raise SystemExit(f'unexpected package member: {relative}')
        mode = 0o755 if path.suffix == '.sh' or path.name == 'update-binary' else 0o644
        entries[relative.as_posix()] = (path.read_bytes(), mode)
entries['zygisk/arm64-v8a.so'] = (library, 0o644)
assert b'version=1.7.6\n' in entries['module.prop'][0]
assert b'id=honor_delta_185\n' in entries['module.prop'][0]
with zipfile.ZipFile(args.out, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, (data, mode) in sorted(entries.items()):
        info = zipfile.ZipInfo(name, date_time=(2026, 11, 20, 0, 0, 0))
        info.create_system = 3
        info.external_attr = (0o100000 | mode) << 16
        archive.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
with zipfile.ZipFile(args.out) as archive:
    if archive.testzip() is not None or any(archive.read(n) != d for n, (d, _) in entries.items()):
        raise SystemExit('ZIP verification failed')
sha = hashlib.sha256(args.out.read_bytes()).hexdigest()
args.out.with_suffix('.zip.sha256').write_text(f'{sha}  {args.out.name}\n')
print(f'{args.out}  SHA-256 {sha}')
