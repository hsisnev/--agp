#!/system/bin/sh
# The existing game detector owns the lease. Only the optional APS policy checks temperature.
agp_lease_valid() {
    [ -f "$BASE/agp-battle-bypass.on" ] && [ ! -e "$BASE/disable" ] && [ ! -e "$BASE/remove" ] || return 1
    [ ! -f "$agp_job/cancel" ] && [ ! -f "$agp_job/restored" ] || return 1
    [ "$(agp_ticks "$agp_parent" 2>/dev/null)" = "$agp_parent_ticks" ] || return 1
    IFS=' ' read -r agp_until agp_package agp_context < "$agp_job/lease" || return 1
    case "$agp_until" in ''|*[!0-9]*) return 1;; esac
    case "$agp_package" in ''|*[!A-Za-z0-9_.]*) return 1;; esac
    case "$agp_context" in game|overlay|ime|float|grace) ;; *) return 1;; esac
    [ "$(agp_now)" -lt "$agp_until" ]
}
agp_hold() (
    exec 8> "$AGP_ROOT/write.lock" || exit 1
    flock 8 8>&8 || exit 1
    agp_lease_valid || exit 1
    [ "$(agp_ticks "$AGP_PID" 2>/dev/null)" = "$AGP_TICKS" ] || exit 1
    agp_byte=$(agp_read "$(agp_mem_path)" "$AGP_ADDR" 1 -tu1)
    case "$agp_byte" in
        0) [ "$(cat "$agp_job/phase")" = applied ] || exit 1;;
        1)
            agp_same_identity "$agp_job" || exit 1
            echo armed > "$agp_job/phase" || exit 1
            agp_write 1 0 || exit 1
            echo applied > "$agp_job/phase" || exit 1;;
        *) echo 'AGP 开关异常；不覆盖外部值' >&2; exit 1;;
    esac
    agp_state "$agp_job" "已保持：$agp_package（$agp_context）；非战斗限制检查=0；定位=$AGP_PROFILE_KIND"
)
agp_guard_cleanup() {
    trap '' INT TERM HUP
    thermal90_clear_job "$agp_job" || :
    for agp_restore_attempt in 1 2 3; do
        aps_result=0
        aps_shield_restore "$agp_job" || aps_result=1
        agp_restore "$agp_job" && [ "$aps_result" = 0 ] && return 0
        sleep 1
    done
    echo '游戏策略恢复未完成，保留备份' >&2
}
agp_guard() {
    agp_job=$1
    IFS=' ' read -r agp_parent agp_parent_ticks < "$agp_job/parent" || return 1
    case "$agp_parent:$agp_parent_ticks" in ''|*[!0-9:]*) return 1;; esac
    echo "$$ $(agp_ticks "$$")" > "$agp_job/guard"
    agp_lease_valid || return 1
    agp_listed "$agp_package" || {
        agp_state "$agp_job" '这个游戏已从名单关闭；未修改内存'
        touch "$agp_job/failed"
        return 1
    }
    agp_identity || {
        agp_state "$agp_job" "${AGP_ERROR:-AGP 校验未通过，查看会话日志}；未申请绕过"
        touch "$agp_job/failed"
        return 1
    }
    [ "$(agp_read "$(agp_mem_path)" "$AGP_ADDR" 1 -tu1)" = 1 ] || {
        agp_state "$agp_job" '原开关不是1；未覆盖已有修改'
        touch "$agp_job/failed"
        return 1
    }
    cp "$AGP_PROFILE" "$agp_job/profile" || return 1
    printf '%s %s %s %s\n' "$AGP_PID" "$AGP_TICKS" "$AGP_BIAS" "$AGP_BOOT" > "$agp_job/identity" || return 1
    echo prepared > "$agp_job/phase" || return 1
    trap agp_guard_cleanup EXIT
    trap 'exit 0' INT TERM HUP
    agp_hold || return 1
    touch "$agp_job/ready"
    agp_last_check=$(agp_now)
    agp_last_package=$agp_package
    agp_last_context=$agp_context
    thermal90_next_check=0
    aps_next_check=0
    aps_next_restore=0
    aps_last_package=
    while agp_lease_valid; do
        # The byte is verified every five seconds, without display-policy polling. Switch/parent/lease checks are lightweight, once per second.
        agp_current_time=$(agp_now)
        if [ "$agp_package:$agp_context" != "$agp_last_package:$agp_last_context" ] ||
           [ $((agp_current_time - agp_last_check)) -ge 5 ]; then
            if [ "$agp_package" != "$agp_last_package" ]; then
                thermal90_clear_job "$agp_job" || break
                thermal90_next_check=0
                agp_listed "$agp_package" || break
            fi
            agp_hold || break
            agp_last_check=$agp_current_time
            agp_last_package=$agp_package
            agp_last_context=$agp_context
        fi
        thermal90_running=0
        if thermal90_active; then
            thermal90_running=1
            [ ! -f "$agp_job/aps.before" ] || aps_shield_restore "$agp_job" || break
            if [ "$agp_current_time" -ge "$thermal90_next_check" ]; then
                thermal90_sync "$agp_job" || :
                thermal90_next_check=$((agp_current_time + 8))
            fi
        else
            thermal90_clear_job "$agp_job" || :
            thermal90_next_check=0
        fi
        if [ "$thermal90_running" = 0 ] && aps_shield_enabled && [ "$agp_context" != grace ]; then
            if [ "$agp_current_time" -ge "$aps_next_check" ] ||
               [ "$agp_package" != "$aps_last_package" ]; then
                aps_shield_sync "$agp_package" "$agp_job" || :
                aps_next_check=$((agp_current_time + 10))
                aps_last_package=$agp_package
            fi
        else
            # The APS policy ends at the start of grace; keep AGP's existing delay.
            if [ -f "$agp_job/aps.before" ] && [ "$agp_current_time" -ge "$aps_next_restore" ]; then
                aps_shield_restore "$agp_job" || :
                aps_next_restore=$((agp_current_time + 5))
            fi
            aps_next_check=0
            aps_last_package=
        fi
        sleep 1
    done
}
