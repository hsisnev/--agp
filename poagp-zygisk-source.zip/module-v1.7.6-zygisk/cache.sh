#!/system/bin/sh
refresh_game_cache() {
    game_signature=$(stat -c '%n:%i:%s:%y:%z' "$BASE/games.list" "$BASE/games.custom.list" "$BASE/games.exclude.list" 2>/dev/null) || :
    if [ "${GAME_CACHE_READY:-0}" = 1 ] && [ "$game_signature" = "$GAME_CACHE_SIGNATURE" ]; then return 0; fi
    set --
    for cache_list in "$BASE/games.list" "$BASE/games.custom.list" "$BASE/games.exclude.list"; do
        [ ! -f "$cache_list" ] || set -- "$@" "$cache_list"
    done
    GAME_PACKAGES=
    game_cache_result=0
    if [ "$#" -gt 0 ]; then
      GAME_PACKAGES=$(awk '
      {sub(/#.*/, ""); gsub(/^[ \t\r]+|[ \t\r]+$/, "")
       if($0 !~ /^[A-Za-z0-9_]+(\.[A-Za-z0-9_]+)+$/) next
       if(FILENAME ~ /\/games[.]exclude[.]list$/) excluded[$0]=1
       else games[$0]=1}
      END {for(package in games) if(!excluded[package]) print package}
      ' "$@" 2>/dev/null)
      game_cache_result=$?
    fi
    if [ "$game_cache_result" -ne 0 ]; then
        GAME_CACHE_READY=0
        return 1
    fi
    GAME_CACHE_SIGNATURE=$game_signature
    GAME_CACHE_READY=1
}
