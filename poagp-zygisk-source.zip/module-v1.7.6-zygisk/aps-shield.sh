#!/system/bin/sh
# Private APS ABI verified on this build only. 185 is the APS release value
# observed on this firmware, not a requested physical display mode.
APS_SHIELD_BUILD='HONOR/AAK-AN00/HNAAK:16/HONORAAK-AN00/10DLDLD175C00E170:user/release-keys'
APS_SHIELD_RELEASE=185

aps_shield_enabled() {
    [ -f "$BASE/aps-shield.on" ] && [ ! -e "$BASE/disable" ] && [ ! -e "$BASE/remove" ]
}
aps_shield_valid_pkg() {
    case "$1" in ''|*[!A-Za-z0-9_.]*) return 1;; esac
    [ "${#1}" -le 255 ] && printf '%s\n' "$1" | grep -Eq '^[A-Za-z0-9_]+(\.[A-Za-z0-9_]+)+$'
}
aps_shield_supported() { [ "$(getprop ro.build.fingerprint)" = "$APS_SHIELD_BUILD" ]; }
aps_shield_identity() (
    read -r boot < /proc/sys/kernel/random/boot_id || exit 1
    pid=$(pidof system_server) || exit 1
    case "$pid" in ''|*[!0-9]*) exit 1;; esac
    ticks=$(agp_ticks "$pid" 2>/dev/null) || exit 1
    printf '%s %s %s\n' "$boot" "$pid" "$ticks"
)
aps_shield_call() {
    /system/bin/timeout 2 /system/bin/service call aps_service "$@" 2>/dev/null
}
aps_shield_reply_int() (
    hex=$(printf '%s\n' "$1" | sed -n 's/^Result: Parcel([[:space:]]*00000000[[:space:]][[:space:]]*\([0-9a-fA-F]\{8\}\)[[:space:]][[:space:]]*.*)$/\1/p')
    [ "${#hex}" = 8 ] || exit 1
    # Only the values used here need decoding. Avoid signed-width differences.
    case "$hex" in
        [fF][fF][fF][fF][fF][fF][fF][fF]) echo -1;;
        000000[0-9a-fA-F][0-9a-fA-F]) echo "$((0x$hex))";;
        *) exit 1;;
    esac
)
aps_shield_get() (
    reply=$(aps_shield_call 29 s16 "$1") || exit 1
    aps_shield_reply_int "$reply"
)
aps_shield_set() (
    reply=$(aps_shield_call 28 s16 "$1" i32 "$2") || exit 1
    [ "$(aps_shield_reply_int "$reply")" = 0 ]
)
aps_shield_thermal_dump() {
    /system/bin/timeout 3 /system/bin/dumpsys -t 2 thermalservice 2>/dev/null
}
aps_shield_thermal_ok() (
    dump=$(aps_shield_thermal_dump) || exit 1
    # Require a live skin reading, a ready HAL, and no manually overridden status.
    printf '%s\n' "$dump" | awk '
        /^IsStatusOverride: false$/ {normal++}
        /^HAL Ready: true$/ {ready++}
        /^Thermal Status: [0-4]$/ {allowed++}
        /^Thermal Status:/ {statuses++}
        /^Current temperatures from HAL:$/ {live=1}
        /Temperature\{.*mType=3,/ {
            if (!match($0, /mValue=[0-9]+(\.[0-9]+)?,/)) {bad=1; next}
            value=substr($0,RSTART+7,RLENGTH-8)+0
            if (value<10 || value>=50 || $0 !~ /mStatus=[0-4]\}/) bad=1
            if (live) skin++
        }
        END {exit !(normal==1 && ready==1 && statuses==1 && allowed==1 && skin>0 && !bad)}'
)
aps_shield_status() (
    [ "$(cat "$1/aps.status" 2>/dev/null)" != "$2" ] || exit 0
    printf '%s\n' "$2" > "$1/aps.status.tmp.$$" && mv -f "$1/aps.status.tmp.$$" "$1/aps.status"
)
# Call with aps.lock held. The journal is written before each change.
aps_shield_restore_locked() (
    journal=$1/aps.before
    [ -f "$journal" ] || exit 0
    read -r pkg old boot pid ticks extra < "$journal" || exit 1
    aps_shield_valid_pkg "$pkg" && [ -n "$boot" ] && [ -z "$extra" ] || exit 1
    case "$old" in 61|90) ;; *) exit 1;; esac
    read -r current_boot < /proc/sys/kernel/random/boot_id || exit 1
    if [ "$current_boot" != "$boot" ]; then
        rm -f "$journal"
        exit
    fi
    identity=$(aps_shield_identity) || exit 1
    if [ "$identity" != "$boot $pid $ticks" ]; then
        rm -f "$journal"
        exit
    fi
    aps_shield_supported || exit 1
    current=$(aps_shield_get "$pkg") || exit 1
    if [ "$current" = "$APS_SHIELD_RELEASE" ]; then
        [ "$(aps_shield_identity)" = "$identity" ] || exit 1
        aps_shield_set "$pkg" "$old" && [ "$(aps_shield_get "$pkg")" = "$old" ] || exit 1
        echo "APS 已恢复：$pkg $old"
    else
        echo "APS 保留系统当前值：$pkg $current"
    fi
    rm -f "$journal"
)
aps_shield_restore() (
    # Also take the lock when the switch is off but a guard may be mid-write.
    [ -f "$1/aps.before" ] || { [ ! -f "$AGP_ROOT/aps.lock" ] && exit 0; }
    exec 7> "$AGP_ROOT/aps.lock" || exit 1
    flock 7 7>&7 || exit 1
    if aps_shield_restore_locked "$1"; then
        [ ! -f "$1/aps.status" ] || aps_shield_status "$1" '已交回系统'
    else
        aps_shield_status "$1" '恢复未确认，已保留记录'
        exit 1
    fi
)
aps_shield_active() (
    aps_shield_enabled && agp_lease_valid &&
        [ "$agp_package" = "$1" ] && [ "$agp_context" != grace ]
)
aps_shield_sync() (
    pkg=$1
    job=$2
    aps_shield_valid_pkg "$pkg" || exit 1
    exec 7> "$AGP_ROOT/aps.lock" || exit 1
    flock 7 7>&7 || exit 1
    aps_shield_active "$pkg" || exit 0
    if [ -f "$job/aps.before" ]; then
        read -r journal_pkg ignored < "$job/aps.before" || exit 1
        if [ "$journal_pkg" != "$pkg" ] && ! aps_shield_restore_locked "$job"; then
            aps_shield_status "$job" '上一个游戏的 APS 尚待恢复'
            exit 1
        fi
    fi
    if [ -f "$job/aps.recovery-pending" ]; then
        pending=0
        for previous in "$AGP_ROOT"/session.*; do
            [ "$previous" != "$job" ] && [ ! -L "$previous" ] && [ -f "$previous/aps.before" ] || continue
            aps_shield_restore_locked "$previous" || pending=1
        done
        if [ "$pending" = 1 ]; then
            aps_shield_status "$job" '上一个会话的 APS 尚待恢复'
            exit 1
        fi
        rm -f "$job/aps.recovery-pending" || exit 1
    fi
    if ! aps_shield_supported; then
        aps_shield_status "$job" '此固件尚未验证 APS 接口'
        exit 0
    fi
    if [ ! -f "$job/aps.before" ]; then
        observed=$(aps_shield_get "$pkg") || {
            aps_shield_status "$job" '暂时无法读取 APS'
            exit 1
        }
        case "$observed" in
            61|90) ;;
            "$APS_SHIELD_RELEASE")
                aps_shield_status "$job" '当前没有需要解除的 APS 限帧'
                exit 0;;
            *)
                aps_shield_status "$job" "当前 APS 值由系统管理（$observed）"
                exit 0;;
        esac
    fi
    if ! aps_shield_thermal_ok; then
        if aps_shield_restore_locked "$job"; then
            aps_shield_status "$job" '机身达到 50°C、紧急温控或读数异常，APS 已交回系统'
        else
            aps_shield_status "$job" '已请求交回系统，APS 恢复尚未确认'
        fi
        exit 0
    fi
    identity=$(aps_shield_identity) && current=$(aps_shield_get "$pkg") || {
        aps_shield_status "$job" '暂时无法读取 APS'
        exit 1
    }
    if [ -f "$job/aps.before" ]; then
        read -r journal_pkg previous_value previous_identity < "$job/aps.before" || exit 1
        if [ "$identity" != "$previous_identity" ]; then
            # APS state belongs to system_server. The replacement owns its values.
            aps_shield_restore_locked "$job" || exit 1
        fi
    fi
    case "$current" in
        "$APS_SHIELD_RELEASE")
            if [ -f "$job/aps.before" ]; then
                aps_shield_status "$job" "已临时解除 APS 限帧（$pkg）"
            else
                aps_shield_status "$job" '当前没有需要解除的 APS 限帧'
            fi
            exit 0;;
        61|90) ;;
        *)
            aps_shield_restore_locked "$job" || exit 1
            aps_shield_status "$job" "当前 APS 值由系统管理（$current）"
            exit 0;;
    esac
    # Recheck the lease and server after the potentially slow read-only calls.
    [ "$(aps_shield_identity)" = "$identity" ] && aps_shield_active "$pkg" || exit 0
    printf '%s %s %s\n' "$pkg" "$current" "$identity" > "$job/aps.before.tmp.$$" &&
        mv -f "$job/aps.before.tmp.$$" "$job/aps.before" || exit 1
    if ! aps_shield_set "$pkg" "$APS_SHIELD_RELEASE" || [ "$(aps_shield_get "$pkg")" != "$APS_SHIELD_RELEASE" ]; then
        aps_shield_status "$job" 'APS 写入未确认，已保留恢复记录'
        exit 1
    fi
    echo "APS 暂时解除：$pkg $current -> $APS_SHIELD_RELEASE"
    aps_shield_status "$job" "已临时解除 APS 限帧（$pkg）"
)
