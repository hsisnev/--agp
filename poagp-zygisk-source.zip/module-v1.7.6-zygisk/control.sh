#!/system/bin/sh
# Game sessions. Use the root identity supplied by the launcher.
PATH=/system/bin:/system/xbin
export PATH
umask 077
BASE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
SELF="$BASE/control.sh"
STATE=/data/local/tmp/honor185-runtime
TARGET=
MATCHED_GAME=
EXIT_DEADLINE=0
CONTEXT=idle
# Optional per-toggle Widevine freeze: the flag file lives in the module dir so
# the WebUI switch survives reboot; restore is SIGCONT, never a leftover kill.
WIDEVINE_MATCH='android.hardware.drm-service-lazy.widevine'
WIDEVINE_FROZEN=0
WV_DESC=off
# Exact game matching; only verified notification/game-assistant overlays may
# retain the underlying game session. Background processes alone never qualify.
focused_package() {
    sed -n 's/.* u[0-9][0-9]* \([^ /}]*\)\/.*/\1/p' | head -n 1
}
list_packages() {
    for list in "$@"; do
        [ -f "$list" ] || continue
        awk '{sub(/#.*/, ""); gsub(/^[ \t\r]+|[ \t\r]+$/, "");
              if ($0 ~ /^[A-Za-z0-9_]+(\.[A-Za-z0-9_]+)+$/) print}' "$list"
    done
}
is_game() {
    [ -n "$1" ] || return 1
    if [ "${GAME_CACHE_READY:-0}" = 1 ]; then
        case "
$GAME_PACKAGES
" in
          *"
$1
"*) return 0;;
          *) return 1;;
        esac
    fi
    list_packages "$BASE/games.exclude.list" | grep -F -x "$1" > /dev/null && return 1
    list_packages "$BASE/games.list" "$BASE/games.custom.list" | grep -F -x "$1" > /dev/null
}
monotonic_millis() {
    read -r uptime ignored < /proc/uptime
    seconds=${uptime%%.*}
    fraction=${uptime#*.}000
    fraction=${fraction%"${fraction#???}"}
    echo $((seconds * 1000 + 1$fraction - 1000))
}
uptime_seconds() {
    read -r uptime ignored < /proc/uptime
    echo "${uptime%%.*}"
}
focused_owner() {
    # Input: whole window dump; $1: current focused Window token.
    awk -v token="$1" '
      /^  Window #[0-9]+ Window\{/ {selected=index($0, "Window{" token " ")>0}
      selected && /mOwnerUid=.*package=/ {
          sub(/.*package=/, ""); sub(/[ \t].*/, ""); print; exit
      }
    '
}
overlay_focus() {
    case "$1" in
        *' NotificationShade}'*|*' StatusBar}'*|*' NotificationPanel}'*|*' ControlCenter}'*) return 0;;
    esac
    # The app is allowed only with a game underneath, never as a game itself.
    [ "$2" = com.hihonor.gameassistant ]
}
rendered_game() {
    # Among listed games, find the one that still owns a rendered surface on
    # screen. Used to hold the session while a chat/IME floating window takes
    # focus - the game is still drawing underneath, so no release is needed.
    # Prints the package on stdout, empty when none qualifies.
    [ -f "$STATE/window.txt" ] || return 1
    awk '
      /^  Window #[0-9]+ Window\{/ {
        if (pkg != "" && surface && visible && screen) print pkg;
        pkg = "";
        if (match($0, / [A-Za-z0-9_.]+\//))
          pkg = substr($0, RSTART + 1, RLENGTH - 2);
        surface = visible = screen = 0
      }
      /mHasSurface=true/ {surface=1}
      /^[ \t]*isVisible=true/ {visible=1}
      /^[ \t]*isOnScreen=true/ {screen=1}
      END {if (pkg != "" && surface && visible && screen) print pkg}
    ' "$STATE/window.txt" | while IFS= read -r pkg; do
        is_game "$pkg" && { printf '%s\n' "$pkg"; break; }
    done
}
visible_session_game() {
    [ -n "$MATCHED_GAME" ] && is_game "$MATCHED_GAME" || return 1
    # Window sections are isolated: don't confuse another window's visibility
    # with the cached game's window. Require its actual rendered surface.
    awk -v pkg="$MATCHED_GAME" '
      function flush() {if (game && surface && visible && screen) found=1}
      /^  Window #[0-9]+ Window\{/ {
        flush(); game=index($0, " " pkg "/")>0; surface=visible=screen=0
      }
      /mHasSurface=true/ {surface=1}
      /^[ \t]*isVisible=true/ {visible=1}
      /^[ \t]*isOnScreen=true/ {screen=1}
      END {flush(); exit !found}
    '
}
select_session() {
    # Inputs supplied by observation; pure state transitions are testable.
    # $1 awake, $2 focused package, $3 focused window, $4 focused app,
    # $5 visible cached game, $6 monotonic milliseconds, $7 verified overlay owner.
    # $8 current IME package, $9 IME input-target package (optional OEM field),
    # $10 package of a still-rendered game window (floating-window hold).
    TARGET=
    CONTEXT=idle
    if [ "$1" = 1 ]; then
        if is_game "$2"; then
            TARGET=$2
            CONTEXT=game
        elif [ -n "${8:-}" ] && [ "${7:-$2}" = "$8" ]; then
            # Only the selected IME may retain a game. A keyboard opened over
            # another foreground app must never retain a visible/background game.
            if is_game "$4" && { [ -z "${9:-}" ] || [ "$9" = "$4" ]; }; then
                TARGET=$4
                CONTEXT=ime
            elif { [ -z "$4" ] || [ "$4" = "$8" ]; } &&
                 [ "$5" = 1 ] && [ "${9:-}" = "$MATCHED_GAME" ] && is_game "$MATCHED_GAME"; then
                TARGET=$MATCHED_GAME
                CONTEXT=ime
            fi
        elif overlay_focus "$3" "${7:-$2}"; then
            if is_game "$4"; then
                TARGET=$4
                CONTEXT=overlay
            elif [ "$5" = 1 ] && is_game "$MATCHED_GAME"; then
                TARGET=$MATCHED_GAME
                CONTEXT=overlay
            fi
        fi
        # A floating chat/IME window may take focus while the game keeps
        # rendering underneath. Prefer the verified IME/overlay contexts above
        # (they carry stricter checks); fall back to the rendered-window hold
        # so replying in a floating window does not flap the display policy.
        if [ -z "$TARGET" ] && [ -n "${10:-}" ] && is_game "${10}"; then
            TARGET=${10}
            CONTEXT=float
        elif [ -z "$TARGET" ] && is_game "$4" && [ "$4" != "$2" ]; then
            # mFocusedApp is a listed game while a different window (floating
            # chat/IME) holds mCurrentFocus. Cannot trigger when the game is
            # backgrounded - mFocusedApp then points at the new foreground.
            TARGET=$4
            CONTEXT=float
        fi
    fi
    if [ -n "$TARGET" ]; then
        MATCHED_GAME=$TARGET
        EXIT_DEADLINE=0
        return 0
    fi
    # Sleep/lock and explicit stop bypass grace, returning control promptly.
    if [ "$1" = 1 ] && [ -n "$MATCHED_GAME" ] && is_game "$MATCHED_GAME"; then
        if [ "$EXIT_DEADLINE" = 0 ]; then EXIT_DEADLINE=$(($6 + 6000)); fi
        if [ "$6" -lt "$EXIT_DEADLINE" ]; then
            TARGET=$MATCHED_GAME
            CONTEXT=grace
            return 0
        fi
    fi
    MATCHED_GAME=
    EXIT_DEADLINE=0
    return 1
}
widevine_thaw() {
    # SIGCONT on a running process is harmless; always clear leftovers.
    for wv_pid in $(pgrep -f "$WIDEVINE_MATCH" 2>/dev/null); do
        # pgrep -f also matches the caller's own cmdline; never signal self/parent.
        { [ "$wv_pid" = "$$" ] || [ "$wv_pid" = "$PPID" ]; } && continue
        kill -CONT "$wv_pid" 2>/dev/null
    done
    WIDEVINE_FROZEN=0
}
widevine_sync() {
    WV_DESC=off
    [ -f "$BASE/widevine-freeze.on" ] && WV_DESC=pending
    if [ -f "$BASE/widevine-freeze.on" ] && [ -n "$TARGET" ]; then
        wv_found=0
        for wv_pid in $(pgrep -f "$WIDEVINE_MATCH" 2>/dev/null); do
            { [ "$wv_pid" = "$$" ] || [ "$wv_pid" = "$PPID" ]; } && continue
            wv_found=1
            kill -STOP "$wv_pid" 2>/dev/null
        done
        if [ "$wv_found" = 1 ]; then
            [ "$WIDEVINE_FROZEN" = 1 ] || log "已冻结 $WIDEVINE_MATCH"
            WIDEVINE_FROZEN=1
            WV_DESC=frozen
        else
            WV_DESC=absent
        fi
    elif [ "$WIDEVINE_FROZEN" = 1 ]; then
        widevine_thaw
        log "已恢复 $WIDEVINE_MATCH"
    fi
}
root_check() { [ "$(id -u)" = 0 ] || { echo '需要当前终端已获得 Root；本脚本不会自行提权。'; exit 1; }; }
log() { echo "$(date '+%F %T') $*" >> "$STATE/run.log"; }
boot_id() { cat /proc/sys/kernel/random/boot_id; }
alive() {
    [ -f "$STATE/pid" ] || return 1
    P=$(cat "$STATE/pid")
    case "$P" in ''|*[!0-9]*) return 1;; esac
    kill -0 "$P" 2>/dev/null || return 1
    tr '\000' ' ' < "/proc/$P/cmdline" | grep -F "$SELF daemon" >/dev/null
}

. "$BASE/cache.sh"
. "$BASE/events.sh"
. "$BASE/agp-session.sh"
legacy_pending() { [ -f "$STATE/applied" ] || [ -f "$STATE/aps.before" ]; }
legacy_recover() {
    legacy_pending || return 0
    /system/bin/sh "$BASE/legacy/restore.sh" >> "$STATE/launcher.log" 2>&1 || return 1
    ! legacy_pending
}
cleanup() {
    agp_release
    event_stop
    echo 'stopped：事件小程序已停止' > "$STATE/events.status"
    widevine_thaw
    echo 'STOPPED：自动监测已停止，AGP恢复结果见策略状态。' > "$STATE/status"
    rm -f "$STATE/pid" "$STATE/stop"
    rmdir "$STATE/lock" 2>/dev/null
}
root_check
mkdir -p "$STATE" || exit 1
[ -L "$STATE" ] && { echo '状态目录不能是符号链接'; exit 1; }
[ "$(stat -c %u "$STATE")" = 0 ] || { echo '状态目录必须属于 root'; exit 1; }
chmod 700 "$STATE"
case "${1:-start}" in
start)
    # Accept old launchers' auto/rate argument; it no longer fixes a rate.
    if alive; then echo '自动监测已在运行。'; exit 0; fi
    [ ! -f "$BASE/disable" ] && [ ! -f "$BASE/remove" ] || { echo '模块已禁用或待卸载'; exit 1; }
    [ -x /system/bin/setsid ] || { echo '系统缺少setsid，无法可靠后台启动'; exit 1; }
    /system/bin/setsid /system/bin/sh "$SELF" daemon >> "$STATE/launcher.log" 2>&1 < /dev/null &
    sleep 2
    if alive; then echo '已启动：等待名单内游戏，刷新率由系统选择'; else cat "$STATE/launcher.log"; exit 1; fi
    ;;
daemon)
    if ! mkdir "$STATE/lock" 2>/dev/null; then
        if alive; then exit 1; fi
        rmdir "$STATE/lock" 2>/dev/null || exit 1
        mkdir "$STATE/lock" || exit 1
    fi
    echo $$ > "$STATE/pid"
    trap 'exit 0' INT TERM HUP
    trap cleanup EXIT
    rm -f "$STATE/stop" "$STATE/target.rate" "$STATE/target.mode" "$STATE/requested.rate"
    widevine_thaw
    /system/bin/sh "$BASE/agp-bypass.sh" restore >> "$STATE/launcher.log" 2>&1 || log 'AGP旧记录恢复未完成；保留备份'
    for f in launcher.log run.log events.log; do
        if [ -f "$STATE/$f" ] && [ "$(stat -c %s "$STATE/$f" 2>/dev/null)" -gt 262144 ]; then
            tail -c 131072 "$STATE/$f" > "$STATE/$f.tmp" 2>/dev/null && mv -f "$STATE/$f.tmp" "$STATE/$f"
        fi
    done
    echo 'READY：等待名单内游戏。' > "$STATE/status"
    log '启动：自动识别名单游戏，AGP 退出延迟 6 秒，APS 由页面开关控制'
    LEGACY_NEXT_RETRY=0
    last_ime_check=0
    ime_initialized=0
    ime_component=
    ime_package=
    last_observation=-30
    SLEEP_MONITOR=0
    wake_state=unknown
    event_start || :
    EVENT_BITS=15
    # AGP_ONLY_LOOP
    while [ ! -f "$STATE/stop" ] && [ ! -f "$BASE/disable" ] && [ ! -f "$BASE/remove" ]; do
        loop_uptime=$(uptime_seconds)
        observation_due=0
        if [ $((EVENT_BITS & 17)) != 0 ] || [ $((loop_uptime - last_observation)) -ge 30 ]; then
            observation_due=1
        fi
        if [ "$SLEEP_MONITOR" = 1 ] || [ "$observation_due" = 1 ]; then
            wake_state=unknown
            if dumpsys power > "$STATE/power.txt" 2>/dev/null; then
                if grep -q 'mWakefulness=Awake' "$STATE/power.txt"; then
                    wake_state=awake
                elif grep -Eq 'mWakefulness=(Asleep|Dozing)' "$STATE/power.txt"; then
                    wake_state=asleep
                fi
            fi
        fi
        if [ "$wake_state" = asleep ] || { [ "$SLEEP_MONITOR" = 1 ] && [ "$wake_state" != awake ]; }; then
            select_session 0 '' '' '' 0 "$(monotonic_millis)" '' '' '' '' || :
            agp_release
            if [ "$WIDEVINE_FROZEN" = 1 ]; then widevine_thaw; fi
            SLEEP_MONITOR=1
            echo 'SLEEP：已请求释放AGP修改，等待亮屏。' > "$STATE/status"
            event_wait
            continue
        fi
        if [ "$SLEEP_MONITOR" = 1 ]; then
            SLEEP_MONITOR=0
            EVENT_BITS=15
            observation_due=1
            last_observation=-30
            LEGACY_NEXT_RETRY=0
        fi
        # Old overrides must be released before beginning an AGP-only session.
        # Clean up legacy overrides before the new session can apply a policy.
        if legacy_pending; then
            agp_release
            if [ "$WIDEVINE_FROZEN" = 1 ]; then widevine_thaw; fi
            if [ "$loop_uptime" -ge "$LEGACY_NEXT_RETRY" ]; then
                LEGACY_NEXT_RETRY=$((loop_uptime + 60))
                if legacy_recover; then
                    log '旧版覆盖清理完成，进入AGP单策略监测'
                    EVENT_BITS=15
                    last_observation=-30
                else
                    echo 'MIGRATION_PENDING：旧版覆盖尚待清理，60秒后重试；AGP单策略暂未申请。' > "$STATE/status"
                fi
            fi
            if legacy_pending; then event_wait; continue; fi
        fi
        if [ $((loop_uptime - last_observation)) -ge 30 ]; then
            EVENT_BITS=$((EVENT_BITS | 15))
        fi
        # Only event/reconciliation wakes refresh expensive foreground data.
        # Lease/deadline timers reuse the last observation.
        if [ $((EVENT_BITS & 4)) != 0 ] || [ "${GAME_CACHE_READY:-0}" != 1 ]; then
            refresh_game_cache || GAME_CACHE_READY=0
        fi
        if [ $((EVENT_BITS & 8)) != 0 ]; then ime_initialized=0; fi
        observation_due=0
        if [ $((EVENT_BITS & 17)) != 0 ] || [ $((loop_uptime - last_observation)) -ge 30 ]; then
            observation_due=1
        fi
        if [ "$observation_due" = 1 ]; then
            last_observation=$loop_uptime
            awake=0
            if [ "$wake_state" = awake ]; then awake=1; fi
            if [ "$awake" = 1 ]; then
                # Keep the potentially large window dump on disk; expanding it as a
                # shell argument can exceed ARG_MAX on devices with many windows.
                # When the screen is off there is no foreground to evaluate, so the
                # whole dump is skipped: that is the largest per-poll cost.
                if ! dumpsys window 2>/dev/null > "$STATE/window.txt"; then
                    awake=0
                    log '窗口读取失败，本轮按无前台处理，等待事件或兜底重试'
                fi
                if grep -E 'isKeyguardShowing=true|mKeyguardShowing=true|mShowingLockscreen=true' "$STATE/window.txt" > /dev/null; then awake=0; fi
            fi
            if [ "$awake" = 1 ]; then
                focus=$(grep 'mCurrentFocus=' "$STATE/window.txt" | head -n 1)
                focused=$(printf '%s\n' "$focus" | focused_package)
                underlying=$(grep 'mFocusedApp=' "$STATE/window.txt" | head -n 1 | focused_package)
                token=$(printf '%s\n' "$focus" | sed -n 's/.*Window{\([^ ]*\) .*/\1/p')
                owner=$(focused_owner "$token" < "$STATE/window.txt")
                overlay_package=${owner:-$focused}
            else
                focus=
                focused=
                underlying=
                overlay_package=
                rendered=
            fi
        fi # observation_due
        if [ "$ime_initialized" = 0 ] || [ $((loop_uptime - last_ime_check)) -ge 30 ]; then
            ime_component=$(settings get secure default_input_method)
            ime_package=${ime_component%%/*}
            case "$ime_component" in */*) ;; *) ime_package=;; esac
            last_ime_check=$loop_uptime
            ime_initialized=1
        fi
        if [ "$observation_due" = 1 ]; then
            ime_target=
            visible=0
            if [ "$awake" = 1 ]; then
                ime_target=$(grep -E 'imeInputTarget in display# 0 |mImeInputTarget=|mInputMethodTarget=' "$STATE/window.txt" | head -n 1 | focused_package)
                rendered=$(rendered_game)
                if { overlay_focus "$focus" "$overlay_package" ||
                     { [ -n "$ime_package" ] && [ "$overlay_package" = "$ime_package" ]; }; } &&
                   visible_session_game < "$STATE/window.txt"; then visible=1; fi
            fi
        fi
        previous_game=$MATCHED_GAME
        previous_context=$CONTEXT
        if select_session "$awake" "$focused" "$focus" "$underlying" "$visible" "$(monotonic_millis)" "$overlay_package" "$ime_package" "$ime_target" "$rendered"; then
            if [ "$previous_game:$previous_context" != "$TARGET:$CONTEXT" ]; then
                log "AGP会话：$TARGET context=$CONTEXT deadline=$EXIT_DEADLINE"
            fi
            widevine_sync
            agp_sync
            if [ ! -f "$BASE/agp-battle-bypass.on" ]; then
                echo "BYPASS_OFF：策略已关闭；package=$TARGET context=$CONTEXT" > "$STATE/status"
            elif [ -n "$AGP_JOB" ] && [ -f "$AGP_JOB/ready" ] && agp_guard_alive; then
                echo "AGP_ACTIVE：会话保护中；package=$TARGET context=$CONTEXT exitDeadline=$EXIT_DEADLINE；实际刷新率由系统选择。" > "$STATE/status"
            else
                echo "AGP_WAIT：等待定位与运行校验；未通过原因见AGP策略状态；package=$TARGET context=$CONTEXT；详情见AGP策略状态。" > "$STATE/status"
            fi
        else
            if [ -n "$previous_game" ]; then log "释放游戏：$previous_game，当前窗口：${focused:-unknown}"; fi
            widevine_sync
            agp_release
            echo 'IDLE：无游戏会话；系统管理刷新率。' > "$STATE/status"
        fi
        event_wait
    done
    ;;
stop|restore)
    if alive; then
        touch "$STATE/stop"
        kill -TERM "$P" 2>/dev/null
        n=0
        while alive && [ "$n" -lt 25 ]; do sleep 1; n=$((n+1)); done
        if alive; then echo '进程未退出，请保留状态目录并重试 stop'; exit 1; fi
    fi
    /system/bin/sh "$BASE/agp-bypass.sh" restore || exit 1
    widevine_thaw
    if ! legacy_recover; then
        echo '旧版恢复尚未完成；请亮屏后再次执行 control.sh restore。'
        exit 1
    fi
    echo 'STOPPED：已停止自动监测，已处理AGP恢复记录。' > "$STATE/status"
    cat "$STATE/status"
    ;;
games)
    echo '启用的游戏包名（排除列表优先）：'
    list_packages "$BASE/games.list" "$BASE/games.custom.list" | sort -u |
        while IFS= read -r pkg; do is_game "$pkg" && echo "$pkg"; done
    ;;
status)
    if alive; then echo '守护进程：运行中'; else echo '守护进程：未运行'; fi
    cat "$STATE/status" 2>/dev/null
    cat "$STATE/events.status" 2>/dev/null
    /system/bin/sh "$BASE/agp-bypass.sh" status
    /system/bin/sh "$BASE/agp-bypass.sh" aps-status
    ;;
widevine)
    case "${2:-status}" in
        on)  touch "$BASE/widevine-freeze.on"; echo '已开启：游戏前台时冻结 Widevine DRM 进程';;
        off) rm -f "$BASE/widevine-freeze.on"; widevine_thaw; echo '已关闭并恢复 Widevine DRM 进程';;
        status)
            if [ -f "$BASE/widevine-freeze.on" ]; then echo '开关：开启'; else echo '开关：关闭'; fi
            for wv_pid in $(pgrep -f "$WIDEVINE_MATCH" 2>/dev/null); do
                [ "$wv_pid" = "$$" ] || [ "$wv_pid" = "$PPID" ] || echo "$wv_pid"
            done
            ;;
        *) echo '/system/bin/sh control.sh widevine on | off | status'; exit 1;;
    esac
    ;;
*) echo '/system/bin/sh control.sh start | stop | restore | status | games | widevine on/off'; exit 1;;
esac
