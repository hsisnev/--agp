#!/system/bin/sh
PATH=/system/bin:/system/xbin
export PATH
umask 077
BASE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
[ "$(id -u)" = 0 ] || { echo '需要Root管理器提供权限' >&2; exit 1; }
packages() {
    [ -f "$1" ] || return 0
    awk '{sub(/#.*/, ""); gsub(/^[ \t\r]+|[ \t\r]+$/, "");
      if ($0 ~ /^[A-Za-z0-9_]+(\.[A-Za-z0-9_]+)+$/) print}' "$1"
}
valid() {
    case "$1" in ''|*[!A-Za-z0-9_.]*) return 1;; esac
    [ "${#1}" -le 255 ] && printf '%s\n' "$1" | grep -E '^[A-Za-z0-9_]+(\.[A-Za-z0-9_]+)+$' > /dev/null
}
write_list() {
    file="$BASE/$1"
    op=$2
    tmp="$BASE/.$1.webui.$$"
    if [ -f "$file" ]; then cp -f "$file" "$file.webui.bak" || return 1; fi
    {
        echo '# 通过模块名单管理页面维护；每行一个精确包名。'
        { packages "$file" | grep -F -x -v "$PKG"; [ "$op" != add ] || echo "$PKG"; } | sort -u
    } > "$tmp" || return 1
    chmod 0644 "$tmp" && mv -f "$tmp" "$file"
}
case "${1:-read}" in
read)
    awk '/^[ \t]*#/ {next} {
      line=$0; sub(/#.*/, "", line); gsub(/^[ \t\r]+|[ \t\r]+$/, "", line);
      if (line !~ /^[A-Za-z0-9_]+(\.[A-Za-z0-9_]+)+$/) next;
      label=$0; if (index(label,"#")) {sub(/^[^#]*#[ \t]*/, "", label)} else label=line;
      gsub(/[\t\r]/," ",label); print "B\t" line "\t" label;
    }' "$BASE/games.list" || exit 1
    packages "$BASE/games.custom.list" | while IFS= read -r p; do printf 'C\t%s\n' "$p"; done
    packages "$BASE/games.exclude.list" | while IFS= read -r p; do printf 'E\t%s\n' "$p"; done
    cmd package list packages | sed -n 's/^package:/I\t/p'
    running=0
    if [ -f /data/local/tmp/honor185-runtime/pid ]; then
        pid=$(cat /data/local/tmp/honor185-runtime/pid)
        case "$pid" in
          ''|*[!0-9]*) ;;
          *) if kill -0 "$pid" 2>/dev/null &&
                tr '\000' ' ' < "/proc/$pid/cmdline" | grep -F "$BASE/control.sh daemon" > /dev/null; then running=1; fi;;
        esac
    fi
    printf 'D\t%s\n' "$running"
    wv=0
    [ -f "$BASE/widevine-freeze.on" ] && wv=1
    printf 'W\t%s\n' "$wv"
    agp_enabled=0
    [ ! -f "$BASE/agp-battle-bypass.on" ] || agp_enabled=1
    printf 'A\t%s\n' "$agp_enabled"
    agp_status=$(/system/bin/sh "$BASE/agp-bypass.sh" status) || agp_status='状态读取失败'
    printf 'G\t%s\n' "$agp_status"
    aps_enabled=0
    [ ! -f "$BASE/aps-shield.on" ] || aps_enabled=1
    thermal_enabled=0
    [ ! -f "$BASE/thermal90-hook.on" ] || thermal_enabled=1
    printf 'H\t%s\n' "$thermal_enabled"
    /system/bin/sh "$BASE/agp-bypass.sh" thermal90-status 2>/dev/null | sed 's/^/Q\t/'
    printf 'T\t%s\n' "$aps_enabled"
    aps_status=$(/system/bin/sh "$BASE/agp-bypass.sh" aps-status) || aps_status='状态读取失败'
    printf 'P\t%s\n' "$aps_status"
    if [ -f /data/local/tmp/honor185-runtime/status ]; then
        sed 's/^/S\t/' /data/local/tmp/honor185-runtime/status
    fi
    if [ -f /data/local/tmp/honor185-runtime/events.status ]; then
        sed 's/^/N\t/' /data/local/tmp/honor185-runtime/events.status
    fi
    ;;
agpon|agpoff)
    [ "$#" = 1 ] || exit 2
    if [ "$1" = agpon ]; then
        touch "$BASE/agp-battle-bypass.on" && chmod 0644 "$BASE/agp-battle-bypass.on" || exit 1
        # Wake the existing FileObserver without changing any package entry.
        : >> "$BASE/games.custom.list"
        echo '已开启：名单游戏会话内自动解除非战斗60Hz限制'
    else
        /system/bin/sh "$BASE/agp-bypass.sh" off || exit 1
    fi
    ;;
apson|apsoff)
    [ "$#" = 1 ] || exit 2
    if [ "$1" = apson ]; then
        . "$BASE/aps-shield.sh"
        aps_shield_supported || { echo '此固件尚未验证 APS 接口' >&2; exit 1; }
        touch "$BASE/aps-shield.on" && chmod 0644 "$BASE/aps-shield.on"
    else
        /system/bin/sh "$BASE/agp-bypass.sh" aps-off
    fi
    ;;
thermalon|thermaloff)
    [ "$#" = 1 ] || exit 2
    if [ "$1" = thermalon ]; then
        . "$BASE/aps-shield.sh"
        . "$BASE/thermal90-hook.sh"
        thermal90_supported || { echo '此固件的 90 限制尚未验证' >&2; exit 1; }
        touch "$BASE/thermal90-hook.on" && chmod 0644 "$BASE/thermal90-hook.on"
    else
        /system/bin/sh "$BASE/agp-bypass.sh" thermal90-off
    fi
    ;;
wvon|wvoff)
    case "$1" in
      wvon)
        umask 022
        touch "$BASE/widevine-freeze.on"
        chmod 0644 "$BASE/widevine-freeze.on";;
      wvoff)
        rm -f "$BASE/widevine-freeze.on"
        for wv_pid in $(pgrep -f 'android.hardware.drm-service-lazy.widevine' 2>/dev/null); do
            { [ "$wv_pid" = "$$" ] || [ "$wv_pid" = "$PPID" ]; } && continue
            kill -CONT "$wv_pid" 2>/dev/null
        done;;
    esac
    echo OK
    ;;
add|remove|enable|disable)
    PKG=${2:-}
    valid "$PKG" || { echo '无效包名：仅允许字母、数字、下划线和点' >&2; exit 2; }
    [ "$#" = 2 ] || { echo '参数错误' >&2; exit 2; }
    LOCK="$BASE/.webui.lock"
    mkdir "$LOCK" 2>/dev/null || { echo '正在保存，请稍后重试；若进程异常中止，请检查.webui.lock' >&2; exit 3; }
    trap 'rm -f "$BASE"/.*.webui."$$"; rmdir "$LOCK" 2>/dev/null' EXIT
    trap 'exit 1' INT TERM HUP
    case "$1" in
      add)
        if ! packages "$BASE/games.list" | grep -F -x "$PKG" > /dev/null; then
            write_list games.custom.list add || exit 1
        fi
        write_list games.exclude.list remove || exit 1;;
      remove)
        write_list games.custom.list remove || exit 1
        write_list games.exclude.list remove || exit 1;;
      enable) write_list games.exclude.list remove || exit 1;;
      disable) write_list games.exclude.list add || exit 1;;
    esac
    echo OK
    ;;
*) echo '未知操作' >&2; exit 2;;
esac
