package agp;

import android.content.Context;
import android.content.BroadcastReceiver;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.ContentObserver;
import android.hardware.display.DisplayManager;
import android.os.Binder;
import android.os.FileObserver;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Parcel;
import android.os.PowerManager;
import android.os.RemoteException;
import android.os.SystemClock;
import android.provider.Settings;
import android.system.ErrnoException;
import android.system.Os;
import android.system.OsConstants;
import android.view.Display;
import java.io.File;
import java.io.FileDescriptor;
import java.util.List;
import java.util.function.Consumer;

/** Read-only Android event bridge. Never writes display/APS/accessibility settings. */
public final class AgpEvents {
    static final int WINDOW = 1, DISPLAY = 2, FILES = 4, SETTINGS = 8, WAKE = 16, READY = 32;
    final Handler handler = new Handler(Looper.getMainLooper());
    final File base, state, parent;
    final FileDescriptor output;
    final boolean probe;
    int pending;
    long lastWrite;
    String windowSignature;
    java.lang.reflect.Field focusableField;
    boolean windowFieldsKnown;
    Object wm, windowListener, taskService, taskObserver;
    Consumer<List<?>> windowConsumer;
    DisplayManager displayManager;
    FileObserver baseObserver, stateObserver;
    ContentObserver settingsObserver;
    PowerManager powerManager;
    BroadcastReceiver screenReceiver;
    volatile boolean interactive = true;

    AgpEvents(String[] args) throws Exception {
        probe = args.length == 1 && "--probe".equals(args[0]);
        if (!probe && args.length != 4) throw new IllegalArgumentException("fifo base state parentPid | --probe");
        output = probe ? null : Os.open(args[0], OsConstants.O_WRONLY | OsConstants.O_NONBLOCK, 0);
        base = probe ? null : new File(args[1]);
        state = probe ? null : new File(args[2]);
        parent = probe ? null : new File("/proc/" + Integer.parseInt(args[3]));
    }

    void signal(final int bits) {
        handler.post(new Runnable() {
            @Override public void run() {
                int accepted = interactive ? bits : bits & (WAKE | READY | FILES);
                if (accepted == 0) return;
                if ((accepted & WAKE) != 0) {
                    handler.removeCallbacks(flush);
                    pending |= accepted;
                    handler.post(flush);
                } else {
                    if (pending == 0) handler.postDelayed(flush,
                            Math.max(150, 750 - (SystemClock.uptimeMillis() - lastWrite)));
                    pending |= accepted;
                }
            }
        });
    }

    final Runnable flush = new Runnable() {
        @Override public void run() {
            int bits = pending;
            pending = 0;
            lastWrite = SystemClock.uptimeMillis();
            try {
                if (probe) System.out.println("EVENT " + bits);
                else {
                    byte[] bytes = (bits + "\n").getBytes("US-ASCII");
                    Os.write(output, bytes, 0, bytes.length);
                }
            } catch (ErrnoException e) {
                if (e.errno == OsConstants.EAGAIN) {
                    pending |= bits;
                    handler.postDelayed(this, 1000);
                } else fatal(e);
            } catch (Exception e) { fatal(e); }
        }
    };

    static Object service(String name, String stub) throws Exception {
        Object binder = Class.forName("android.os.ServiceManager")
                .getMethod("getService", String.class).invoke(null, name);
        return Class.forName(stub).getMethod("asInterface", IBinder.class).invoke(null, binder);
    }

    void registerTasks() throws Exception {
        taskService = service("activity_task", "android.app.IActivityTaskManager$Stub");
        Class<?> stub = Class.forName("android.app.ITaskStackListener$Stub");
        final SetOfCodes codes = new SetOfCodes(stub);
        Binder callback = new Binder() {
            @Override protected boolean onTransact(int code, Parcel data, Parcel reply, int flags)
                    throws RemoteException {
                if (code >= FIRST_CALL_TRANSACTION && code <= LAST_CALL_TRANSACTION) {
                    data.enforceInterface("android.app.ITaskStackListener");
                    if (codes.contains(code)) signal(WINDOW);
                    if (reply != null) reply.writeNoException();
                    return true;
                }
                return super.onTransact(code, data, reply, flags);
            }
        };
        taskObserver = stub.getMethod("asInterface", IBinder.class).invoke(null, callback);
        Class.forName("android.app.IActivityTaskManager")
                .getMethod("registerTaskStackListener", Class.forName("android.app.ITaskStackListener"))
                .invoke(taskService, taskObserver);
    }

    static final class SetOfCodes {
        final java.util.HashSet<Integer> values = new java.util.HashSet<Integer>();
        SetOfCodes(Class<?> stub) throws Exception {
            for (String name : new String[] {"onTaskStackChanged", "onTaskMovedToFront",
                    "onTaskFocusChanged", "onTaskDisplayChanged", "onTaskRemoved"}) {
                try {
                    java.lang.reflect.Field field = stub.getDeclaredField("TRANSACTION_" + name);
                    field.setAccessible(true);
                    values.add(field.getInt(null));
                } catch (NoSuchFieldException ignored) { }
            }
            if (values.isEmpty()) throw new IllegalStateException("task callbacks unavailable");
        }
        boolean contains(int code) { return values.contains(code); }
    }

    void windows(List<?> windows) {
        if (!interactive) return;
        try {
            StringBuilder signature = new StringBuilder();
            for (Object window : windows) {
                Class<?> type = window.getClass();
                if (!windowFieldsKnown) {
                    try { focusableField = type.getField("isFocusable"); }
                    catch (NoSuchFieldException ignored) { }
                    windowFieldsKnown = true;
                }
                int displayId = type.getField("displayId").getInt(window);
                if (displayId != Display.DEFAULT_DISPLAY) continue;
                IBinder token = (IBinder) type.getField("windowToken").get(window);
                boolean visible = type.getField("isVisible").getBoolean(window);
                signature.append(token).append(':').append(type.getField("name").get(window))
                        .append(':').append(visible);
                if (focusableField != null) signature.append(':').append(focusableField.getBoolean(window));
                signature.append(';');
            }
            // Position/transform animation and frame presentation never wake the shell.
            synchronized (this) {
                if (signature.toString().equals(windowSignature)) return;
                windowSignature = signature.toString();
            }
            signal(WINDOW);
        } catch (Exception e) { fatal(e); }
    }

    void registerWindows() throws Exception {
        wm = service("window", "android.view.IWindowManager$Stub");
        IBinder wmBinder = (IBinder) Class.forName("android.os.IInterface").getMethod("asBinder").invoke(wm);
        wmBinder.linkToDeath(new IBinder.DeathRecipient() {
            @Override public void binderDied() { fatal(new IllegalStateException("window service died")); }
        }, 0);
        Class<?> type = Class.forName("android.window.WindowInfosListenerForTest");
        windowListener = type.getConstructor().newInstance();
        windowConsumer = new Consumer<List<?>>() {
            @Override public void accept(List<?> windows) { windows(windows); }
        };
        type.getMethod("addWindowInfosListener", Consumer.class).invoke(windowListener, windowConsumer);
    }

    void registerDisplay(Context context) {
        displayManager = (DisplayManager) context.getSystemService(Context.DISPLAY_SERVICE);
        if (displayManager == null) throw new IllegalStateException("display service unavailable");
        displayManager.registerDisplayListener(new DisplayManager.DisplayListener() {
            String last;
            @Override public void onDisplayAdded(int id) { if (id == 0) signal(WINDOW | DISPLAY); }
            @Override public void onDisplayRemoved(int id) { if (id == 0) signal(WINDOW | DISPLAY); }
            @Override public void onDisplayChanged(int id) {
                if (id != 0) return;
                updateInteractive();
                if (!interactive) return;
                Display display = displayManager.getDisplay(id);
                String current = display == null ? "removed" : display.getState() + ":"
                        + display.getRotation();
                if (!current.equals(last)) { last = current; signal(WINDOW | DISPLAY); }
            }
        }, handler);
        settingsObserver = new ContentObserver(handler) {
            @Override public void onChange(boolean selfChange, android.net.Uri uri) {
                if (!interactive) return;
                signal(Settings.Secure.getUriFor("default_input_method").equals(uri)
                        ? WINDOW | SETTINGS : SETTINGS);
            }
        };
        context.getContentResolver().registerContentObserver(Settings.Secure.getUriFor("default_input_method"), false, settingsObserver);
    }

    FileObserver observer(File dir, final boolean module) {
        FileObserver observer = new FileObserver(dir.getPath(), FileObserver.CLOSE_WRITE
                | FileObserver.MOVED_TO | FileObserver.MOVED_FROM | FileObserver.DELETE
                | FileObserver.CREATE | FileObserver.DELETE_SELF | FileObserver.MOVE_SELF) {
            @Override public void onEvent(int event, String path) {
                if (path == null) { signal(WINDOW | FILES); return; }
                if (module && interactive && (path.equals("games.list") || path.equals("games.custom.list")
                        || path.equals("games.exclude.list") || path.equals("widevine-freeze.on")
                        || path.equals("agp-battle-bypass.on"))) signal(WINDOW | FILES);
                if (module && (path.equals("disable") || path.equals("remove"))) signal(FILES);
                if (!module && path.equals("stop")) signal(FILES);
            }
        };
        observer.startWatching();
        return observer;
    }

    void start() throws Exception {
        Object thread = Class.forName("android.app.ActivityThread").getMethod("systemMain").invoke(null);
        Context context = (Context) thread.getClass().getMethod("getSystemContext").invoke(thread);
        registerWake(context);
        registerWindows();
        registerTasks();
        registerDisplay(context);
        if (!probe) {
            baseObserver = observer(base, true);
            stateObserver = observer(state, false);
        }
        handler.postDelayed(new Runnable() {
            @Override public void run() {
                if (!probe && !parent.exists()) System.exit(0);
                updateInteractive();
                signal(interactive ? WINDOW | DISPLAY | FILES | SETTINGS : WAKE);
                handler.postDelayed(this, 30000);
            }
        }, 30000);
        if (probe) handler.postDelayed(new Runnable() {
            @Override public void run() { System.exit(0); }
        }, 5000);
        System.err.println("AGP: window/display/settings/file listeners ready, pid=" + android.os.Process.myPid());
        signal(READY | WAKE | WINDOW | DISPLAY | FILES | SETTINGS);
    }

    void updateInteractive() {
        boolean current = powerManager.isInteractive();
        if (current == interactive) return;
        interactive = current;
        if (!current) {
            pending &= READY | FILES;
            windowSignature = null;
        }
        signal(WAKE | (current ? WINDOW | DISPLAY | FILES | SETTINGS : 0));
    }

    void registerWake(Context context) {
        powerManager = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
        if (powerManager == null) throw new IllegalStateException("power service unavailable");
        interactive = powerManager.isInteractive();
        screenReceiver = new BroadcastReceiver() {
            @Override public void onReceive(Context receiverContext, Intent intent) {
                updateInteractive();
                signal(WAKE);
            }
        };
        IntentFilter filter = new IntentFilter(Intent.ACTION_SCREEN_ON);
        filter.addAction(Intent.ACTION_SCREEN_OFF);
        context.registerReceiver(screenReceiver, filter, null, handler);
    }

    static void fatal(Throwable error) {
        System.err.println("AGP event bridge failed: " + error);
        error.printStackTrace(System.err);
        System.exit(2);
    }

    public static void main(String[] args) {
        try {
            Looper.prepareMainLooper();
            AgpEvents bridge = new AgpEvents(args);
            bridge.start();
            Looper.loop();
        } catch (Throwable error) { fatal(error); }
    }
}
