# AGP 单策略版事件桥

运行时使用随包 events.dex 和系统 app_process。Java 只读取/注册事件；shell 识别游戏并续租 AGP 会话。
无需额外安装应用。停止、卸载、失去 Root 时会尽可能清理；不修改系统安全策略。

窗口/任务变化、屏幕状态/旋转、默认输入法、名单文件和开关触发 FIFO 事件。
刷新率档位、亮度变化不再触发窗口查询；不注册 min/peak_refresh_rate 监听。
协议：WINDOW=1、DISPLAY=2、FILES=4、SETTINGS=8、WAKE=16、READY=32。
事件合并窗口 750ms，唤醒事件优先发送。每 30 秒兜底核对一次窗口；独立 AGP 保护进程负责数据回读。
主循环有游戏时最多等待 10 秒以续租，退出宽限按 6 秒单调时钟截止，息屏只检查唤醒。
事件进程不可用时 10 秒兜底、60 秒重试注册；保留启动命名空间兼容处理。

Android 上重建：

```sh
python event-src/build_android.py
python tests/test_events.py
```

脚本使用现有 Python、app_process；首次下载固定 SHA256 的 JavaIDE 1.4.5 APK（约37MB），
仅提取/使用 ECJ、dx 和 android.jar，不安装 APK。缓存 build-tools/ 不包含在分发包中。
来源：https://github.com/tranleduy2000/javaide （GPL-3.0；内部依赖各依各自许可）。
电脑上可使用 Java 7 兼容目标 javac 与 Android SDK D8 编译，将 classes.dex 命名 events.dex。

独立测试仅更改 tests/ 临时目录，不启动真实模块 daemon、不写真实 AGP。
