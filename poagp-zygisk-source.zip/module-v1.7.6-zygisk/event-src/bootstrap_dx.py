"""Make a tiny ART entrypoint for JavaIDE's int-returning dx.main."""
import struct,hashlib,zlib
p16=lambda x:struct.pack('<H',x)
p32=lambda x:struct.pack('<I',x)
def uleb(x):
 b=bytearray()
 while x>127:b.append((x&127)|128);x>>=7
 b.append(x);return b
strings=sorted(['LBuildDx;','Lcom/duy/dx/command/Main;','Ljava/lang/Object;','Ljava/lang/System;','[Ljava/lang/String;','I','V','VL','IL','VI','main','exit'])
si={s:i for i,s in enumerate(strings)}
types=sorted(['LBuildDx;','Lcom/duy/dx/command/Main;','Ljava/lang/Object;','Ljava/lang/System;','[Ljava/lang/String;','I','V'],key=si.get)
ti={s:i for i,s in enumerate(types)}
protos=sorted([('V',('[Ljava/lang/String;',)),('I',('[Ljava/lang/String;',)),('V',('I',))],key=lambda p:(ti[p[0]],tuple(ti[x] for x in p[1])))
pi={p:i for i,p in enumerate(protos)}
methods=sorted([('LBuildDx;','main',('V',('[Ljava/lang/String;',))),('Lcom/duy/dx/command/Main;','main',('I',('[Ljava/lang/String;',))),('Ljava/lang/System;','exit',('V',('I',)))],key=lambda m:(ti[m[0]],si[m[1]],pi[m[2]]))
mi={(m[0],m[1]):i for i,m in enumerate(methods)}
string_off=112;type_off=string_off+4*len(strings);proto_off=type_off+4*len(types);method_off=proto_off+12*len(protos);class_off=method_off+8*len(methods);data_off=class_off+32
b=bytearray(data_off);sections=[]
def align():
 while len(b)%4:b.append(0)
string_offsets=[]
for s in strings:string_offsets.append(len(b));b.extend(uleb(len(s))+s.encode()+b'\0')
sections.append((0x2002,len(strings),string_offsets[0]))
param_off={}
for param in [('I',),('[Ljava/lang/String;',)]:
 align();param_off[param]=len(b);b.extend(p32(1)+p16(ti[param[0]]))
sections.append((0x1001,2,min(param_off.values())))
align();code_off=len(b)
code=[0x1071,mi[('Lcom/duy/dx/command/Main;','main')],0x0001,0x000a,0x1071,mi[('Ljava/lang/System;','exit')],0x0000,0x000e]
b.extend(p16(2)+p16(1)+p16(1)+p16(0)+p32(0)+p32(len(code))+b''.join(p16(x) for x in code))
sections.append((0x2001,1,code_off))
class_data=len(b);b.extend(bytes([0,0,1,0])+uleb(mi[('LBuildDx;','main')])+uleb(9)+uleb(code_off));sections.append((0x2000,1,class_data))
align();map_off=len(b)
sections += [(0,1,0),(1,len(strings),string_off),(2,len(types),type_off),(3,len(protos),proto_off),(5,len(methods),method_off),(6,1,class_off),(0x1000,1,map_off)]
sections.sort(key=lambda x:x[2]);b.extend(p32(len(sections)))
for t,n,o in sections:b.extend(p16(t)+p16(0)+p32(n)+p32(o))
for i,o in enumerate(string_offsets):struct.pack_into('<I',b,string_off+i*4,o)
for i,t in enumerate(types):struct.pack_into('<I',b,type_off+i*4,si[t])
for i,(ret,args) in enumerate(protos):
 short=ret+''.join('L' if x.startswith(('L','[')) else x for x in args)
 struct.pack_into('<III',b,proto_off+i*12,si[short],ti[ret],param_off[args])
for i,(cl,n,p) in enumerate(methods):struct.pack_into('<HHI',b,method_off+i*8,ti[cl],pi[p],si[n])
struct.pack_into('<IIIIIIII',b,class_off,ti['LBuildDx;'],1,ti['Ljava/lang/Object;'],0,0xffffffff,0,class_data,0)
b[:8]=b'dex\n035\0'
header=[len(b),112,0x12345678,0,0,map_off,len(strings),string_off,len(types),type_off,len(protos),proto_off,0,0,len(methods),method_off,1,class_off,len(b)-data_off,data_off]
struct.pack_into('<20I',b,32,*header);b[12:32]=hashlib.sha1(b[32:]).digest();struct.pack_into('<I',b,8,zlib.adler32(b[12:])&0xffffffff)
open('build-tools/dx-driver.dex','wb').write(b)
