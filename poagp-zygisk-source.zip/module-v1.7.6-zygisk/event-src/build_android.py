"""Build on Android using existing app_process + Python; no package installation."""
from pathlib import Path
import hashlib
import os
import shutil
import subprocess
import sys
import urllib.request
import zipfile

BASE = Path(__file__).resolve().parents[1]
os.chdir(BASE)
TOOLS = BASE / "build-tools"
TOOLS.mkdir(exist_ok=True)
APK = TOOLS / "javaide-1.4.5.apk"
URL = "https://github.com/tranleduy2000/javaide/releases/download/1.4.5/app-release.apk"
SHA256 = "434e9f3ecd83f38e0d9473a804605a8402c9187fbb4bd5c6b81aad0682041644"
if not APK.exists():
    print("Downloading JavaIDE build tools (37 MB)...", flush=True)
    with urllib.request.urlopen(URL, timeout=60) as source, APK.open("wb") as target:
        shutil.copyfileobj(source, target)
if hashlib.sha256(APK.read_bytes()).hexdigest() != SHA256:
    raise SystemExit("Build-tool SHA256 mismatch; inspect/remove build-tools/javaide-1.4.5.apk before retry")
with zipfile.ZipFile(APK) as archive:
    (TOOLS / "android.jar").write_bytes(archive.read("assets/sdk/platforms/android-27/android.jar"))
subprocess.run([sys.executable, "event-src/bootstrap_dx.py"], check=True)
classes = TOOLS / "classes"
if classes.exists():
    shutil.rmtree(classes)
classes.mkdir()
env = {key: value for key, value in os.environ.items()
       if key not in ("LD_LIBRARY_PATH", "LD_PRELOAD")}


def art(classpath, main, *args):
    process_env = dict(env, CLASSPATH=classpath)
    subprocess.run(["/system/bin/app_process", "-Xmx128m", "/system/bin", main, *args],
                   env=process_env, check=True)


art(str(APK), "org.eclipse.jdt.internal.compiler.batch.Main", "-1.7", "-bootclasspath",
    str(TOOLS / "android.jar"), "-d", str(classes), "event-src/AgpEvents.java")
output = TOOLS / "events.new.dex"
if output.exists():
    output.unlink()
art(str(TOOLS / "dx-driver.dex") + ":" + str(APK), "BuildDx", "--dex",
    "--output=" + str(output), str(classes))
if not output.is_file() or not output.read_bytes().startswith(b"dex\n"):
    raise SystemExit("DEX compilation did not produce valid output")
output.replace(BASE / "events.dex")
print("Built events.dex", hashlib.sha256((BASE / "events.dex").read_bytes()).hexdigest())
