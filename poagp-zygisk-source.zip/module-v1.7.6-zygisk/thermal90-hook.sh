#!/system/bin/sh
THERMAL90_KEY=poagp_zygisk90_game_lease
THERMAL90_APK_HASH=6388d529a953505496e5bd5e82696b63e844f48055fca244ab56ddacb1f85e15

thermal90_settings() { /system/bin/timeout 2 /system/bin/settings "$@"; }
thermal90_supported() (
    aps_shield_supported || exit 1
    hash=$(sha256sum /system/app/HnAps/HnAps.apk 2>/dev/null) || exit 1
    [ "${hash%% *}" = "$THERMAL90_APK_HASH" ]
)
thermal90_log() (
    pid=$(pidof com.hihonor.iaware 2>/dev/null) || exit 1
    case "$pid" in ''|*[!0-9]*) exit 1;; esac
    /system/bin/timeout 2 /system/bin/logcat -b main -d --pid="$pid" \
        -s -v raw 'PoAGPZygisk:I' '*:S' 2>/dev/null
)
thermal90_installed() { thermal90_log | grep -qx 'hook.ready.v176'; }
thermal90_show_status() (
    status=$(cat "$1/thermal90.status" 2>/dev/null) || status='Zygisk 已加载，等待名单内游戏'
    if [ -f "$1/thermal90.lease" ]; then
        hit=$(thermal90_log | sed -n 's/^hook.hit.v176 //p' | tail -n 1)
        aps_shield_valid_pkg "$hit" && status="$status。该进程最近命中：$hit"
    fi
    printf '%s\n' "$status"
)
thermal90_active() {
    [ -f "$BASE/thermal90-hook.on" ] && agp_lease_valid &&
        [ "$agp_context" != grace ]
}
thermal90_clear() { thermal90_settings delete global "$THERMAL90_KEY" >/dev/null 2>&1; }
thermal90_clear_job() {
    [ -f "$1/thermal90.lease" ] || return 0
    thermal90_clear && rm -f "$1/thermal90.lease" "$1/thermal90.status"
}
thermal90_sync() (
    job=$1
    thermal90_active || exit 0
    pkg=$agp_package
    aps_shield_valid_pkg "$pkg" && agp_listed "$pkg" || exit 0
    if [ ! -f "$job/thermal90.checked" ] && { ! thermal90_supported || ! thermal90_installed; }; then
        thermal90_clear_job "$job" || :
        thermal90_status "$job" '等待 Zygisk 加载及固件校验'
        exit 0
    fi
    [ -f "$job/thermal90.checked" ] || touch "$job/thermal90.checked" || exit 1
    if ! aps_shield_thermal_ok; then
        thermal90_clear_job "$job" || :
        thermal90_status "$job" '温控等级或温度读数不允许，已交回系统'
        exit 0
    fi
    boot=$(thermal90_settings get global boot_count 2>/dev/null) || exit 1
    case "$boot" in ''|*[!0-9]*) exit 1;; esac
    thermal90_active && [ "$agp_package" = "$pkg" ] || exit 0
    now=$(agp_now) || exit 1
    touch "$job/thermal90.lease" || exit 1
    thermal90_settings put global "$THERMAL90_KEY" "$boot:$((now + 12)):$pkg" >/dev/null 2>&1 || exit 1
    if ! thermal90_active || [ "$agp_package" != "$pkg" ]; then
        thermal90_clear_job "$job" || :
        exit 0
    fi
    thermal90_status "$job" "已为 $pkg 开启拦截，等待系统下发 90"
)

thermal90_status() {
    [ "$(cat "$1/thermal90.status" 2>/dev/null)" != "$2" ] || return 0
    printf '%s\n' "$2" > "$1/thermal90.status.tmp.$$" && mv -f "$1/thermal90.status.tmp.$$" "$1/thermal90.status"
}
