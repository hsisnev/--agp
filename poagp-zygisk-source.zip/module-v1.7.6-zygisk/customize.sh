SKIPMOUNT=true
PROPFILE=false
POSTFSDATA=false
LATESTARTSERVICE=true
ui_print "破-AGP：首次进入游戏自动识别系统开关；识别失败时不写入。"
ui_print "名单游戏温控锁 90 拦截默认关闭。开启 Zygisk 并重启后可用。"
ui_print "机身达到 50°C、紧急温控或读数异常时，游戏 APS 交回系统。"
set_perm_recursive "$MODPATH" 0 0 0755 0644
set_perm "$MODPATH/control.sh" 0 0 0755
set_perm "$MODPATH/webui.sh" 0 0 0755
set_perm "$MODPATH/service.sh" 0 0 0755
set_perm "$MODPATH/uninstall.sh" 0 0 0755
set_perm "$MODPATH/agp-bypass.sh" 0 0 0755

for list in games.custom.list games.exclude.list; do
  OLD="/data/adb/modules/honor_delta_185/$list"
  if [ -f "$OLD" ] && [ "$MODPATH" != /data/adb/modules/honor_delta_185 ]; then
    cp -f "$OLD" "$MODPATH/$list"
    set_perm "$MODPATH/$list" 0 0 0644
  fi
done

# Keep an explicitly disabled new strategy disabled on future upgrades.
OLD_BASE=/data/adb/modules/honor_delta_185
if [ "$MODPATH" != "$OLD_BASE" ] && [ -f "$OLD_BASE/agp-bypass.sh" ] &&
   [ ! -f "$OLD_BASE/agp-battle-bypass.on" ]; then
    rm -f "$MODPATH/agp-battle-bypass.on"
fi

# No action.sh: hide the manager execution/action button.
[ ! -f "$MODPATH/action.sh" ] || rm -f "$MODPATH/action.sh"
