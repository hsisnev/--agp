#!/system/bin/sh
MODDIR=${0%/*}
while [ "$(getprop sys.boot_completed)" != 1 ]; do sleep 3; done
mkdir -p /data/local/tmp/honor185-runtime || exit 1
# Record the start attempt so a silent failure still leaves a trace.
{
    echo "== $(date '+%F %T') service.sh start =="
    /system/bin/sh "$MODDIR/control.sh" start
} >> /data/local/tmp/honor185-runtime/launcher.log 2>&1
