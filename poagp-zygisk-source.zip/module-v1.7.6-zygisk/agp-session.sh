#!/system/bin/sh
# Integration with control.sh's selected TARGET and existing session contexts.
AGP_ROOT=/data/adb/honor185-agp-bypass
AGP_JOB=
AGP_NEXT_RETRY=0
. "$BASE/agp-core.sh"
. "$BASE/aps-shield.sh"
. "$BASE/thermal90-hook.sh"
agp_release() {
    [ -n "$AGP_JOB" ] || return 0
    touch "$AGP_JOB/cancel"
    thermal90_clear_job "$AGP_JOB" || :
    aps_shield_restore "$AGP_JOB" >> "$AGP_JOB/log" 2>&1 || log 'APS 恢复尚未确认，已保留记录'
    agp_restore "$AGP_JOB" || log 'AGP数据开关恢复未完成，备份已保留，独立进程会继续恢复'
    AGP_JOB=
}
agp_guard_alive() {
    [ -f "$AGP_JOB/guard" ] && [ ! -f "$AGP_JOB/restored" ] && [ ! -f "$AGP_JOB/cancel" ] || return 1
    IFS=' ' read -r agp_gpid agp_gticks < "$AGP_JOB/guard"
    case "$agp_gpid:$agp_gticks" in ''|*[!0-9:]*) return 1;; esac
    [ "$(agp_ticks "$agp_gpid" 2>/dev/null)" = "$agp_gticks" ]
}
agp_renew() {
    agp_expiry=$((agp_sync_time + 20))
    if [ "$CONTEXT" = grace ]; then
        agp_grace_end=$(((EXIT_DEADLINE + 999) / 1000))
        [ "$agp_expiry" -le "$agp_grace_end" ] || agp_expiry=$agp_grace_end
    fi
    printf '%s %s %s\n' "$agp_expiry" "$TARGET" "$CONTEXT" > "$AGP_JOB/lease.tmp.$$" &&
        mv -f "$AGP_JOB/lease.tmp.$$" "$AGP_JOB/lease"
}
agp_sync() {
    if [ ! -f "$BASE/agp-battle-bypass.on" ] || [ -z "$TARGET" ]; then
        agp_release
        AGP_NEXT_RETRY=0
        return 0
    fi
    agp_sync_time=$(agp_now)
    if [ -n "$AGP_JOB" ] && agp_guard_alive; then
        agp_renew
        return
    fi
    [ "$agp_sync_time" -ge "$AGP_NEXT_RETRY" ] || return 0
    # Do not begin a new global modification while a game is already leaving.
    [ "$CONTEXT" != grace ] || return 0
    [ ! -L "$AGP_ROOT" ] && mkdir -p "$AGP_ROOT" && chmod 0700 "$AGP_ROOT" || return 1
    [ "$(stat -c %u "$AGP_ROOT")" = 0 ] || return 1
    AGP_NEXT_RETRY=$((agp_sync_time + 300))
    AGP_JOB=$(mktemp -d "$AGP_ROOT/session.XXXXXXXX") || return 1
    echo "$$ $(agp_ticks "$$")" > "$AGP_JOB/parent"
    agp_renew || return 1
    echo '正在校验 AGP 固件与恢复旧记录' > "$AGP_JOB/status"
    /system/bin/setsid /system/bin/sh "$BASE/agp-bypass.sh" _guard "$AGP_JOB" </dev/null >> "$AGP_JOB/log" 2>&1 &
    agp_launch_pid=$!
    agp_wait_count=0
    while [ ! -f "$AGP_JOB/ready" ]; do
        kill -0 "$agp_launch_pid" 2>/dev/null || break
        agp_wait_count=$((agp_wait_count + 1))
        [ "$agp_wait_count" -lt 25 ] || break
        sleep 0.1
    done
    if [ -f "$AGP_JOB/ready" ]; then
        AGP_NEXT_RETRY=0
        log "AGP非战斗限制绕过已启动：$TARGET context=$CONTEXT"
    elif [ -f "$AGP_JOB/busy" ]; then
        AGP_NEXT_RETRY=$((agp_sync_time + 2))
    else
        log 'AGP非战斗限制绕过未就绪，保留诊断；等待重试；刷新率仍由系统管理'
    fi
}
