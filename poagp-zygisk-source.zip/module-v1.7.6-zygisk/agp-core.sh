#!/system/bin/sh
# Verified single-byte AGP data access. Sourced by agp-bypass.sh.
AGP_LIB=/system/lib64/libagp.so
AGP_KNOWN_HASH=7884d804e9d0a5a9775e6f6a400c0d8fe87ad54c236321bfbcd9dea51fc1e746
AGP_PROFILE=
. "$BASE/agp-locator.sh"

agp_now() { read -r agp_u agp_rest < /proc/uptime; echo "${agp_u%%.*}"; }
agp_ticks() (
    IFS= read -r agp_stat < "/proc/$1/stat" || exit 1
    agp_stat=${agp_stat##*) }
    set -- $agp_stat
    [ "$#" -ge 20 ] || exit 1
    case "$1" in Z|X) exit 1;; esac
    shift 19
    echo "$1"
)
agp_read() {
    /system/bin/dd if="$1" bs=1 skip="$2" count="$3" status=none 2>/dev/null |
        /system/bin/od -An "$4" | /system/bin/tr -d ' \n'
}
agp_mem_path() { echo "/proc/$AGP_PID/mem"; }
agp_read_pinned() {
    /system/bin/dd if=/proc/self/fd/6 bs=1 skip="$AGP_ADDR" count=1 status=none 6<&6 2>/dev/null |
        /system/bin/od -An -tu1 | /system/bin/tr -d ' \n'
}
agp_add() { awk -v a="$1" -v b="$2" 'BEGIN {printf "%.0f\n", a+b}'; }
agp_map_addresses() {
    # ELF virtual addresses and ASLR bias remain full-width on Android mksh.
    awk -v f="$AGP_FLAG_RVA" -v g="$AGP_GUARD_RVA" -v anchor="$AGP_ANCHOR" -v lib="$AGP_LIB" \
        -v c1="$AGP_CODE1" -v l1="$AGP_LEN1" -v c2="$AGP_CODE2" -v l2="$AGP_LEN2" \
        -v c3="$AGP_CODE3" -v l3="$AGP_LEN3" '
        function hex(s, i,n,c) {
            s=tolower(s); n=0
            for(i=1;i<=length(s);i++) {
                c=index("0123456789abcdef",substr(s,i,1))-1
                if(c<0) return -1
                n=n*16+c
            }
            return n
        }
        {
            split($1,a,"-"); lo[NR]=hex(a[1]); hi[NR]=hex(a[2]); perm[NR]=$2
            path[NR]=$NF; dev[NR]=$4; inode[NR]=$5
            if($NF==lib && $3 ~ /^0+$/) {base=lo[NR]-anchor; n++; device=$4; ino=$5}
        }
        END {
            if(n!=1 || base<=0 || ino==0 || base+g+8>=281474976710656) exit 1
            code[1]=c1; len[1]=l1; code[2]=c2; len[2]=l2; code[3]=c3; len[3]=l3
            for(i=1;i<=NR;i++) {
                if(perm[i] ~ /^rw-/ && lo[i]<=base+f && base+f<hi[i]) writableFlag++
                if(perm[i] ~ /^rw-/ && lo[i]<=base+g && base+g+8<=hi[i]) writableGuard++
                for(j=1;j<=3;j++) if(path[i]==lib && dev[i]==device && inode[i]==ino &&
                    perm[i] ~ /^r-x/ && lo[i]<=base+code[j] && base+code[j]+len[j]<=hi[i]) found[j]++
            }
            if(writableFlag!=1 || writableGuard!=1 || found[1]!=1 || found[2]!=1 || found[3]!=1) exit 1
            printf "%.0f %.0f %.0f\n",base,base+f,base+g
        }' "$1"
}
agp_code_matches() {
    agp_code_sum=$(/system/bin/dd if="$(agp_mem_path)" bs=1 skip="$(agp_add "$AGP_BIAS" "$1")" count="$2" status=none 2>/dev/null | sha256sum)
    [ "${agp_code_sum%% *}" = "$3" ]
}
agp_identity() {
    agp_resolve || return 1
    set -- $(pidof AGPService)
    [ "$#" = 1 ] || { agp_fail 'AGP 进程不存在或不唯一；等待系统服务就绪'; return 1; }
    AGP_PID=$1
    case "$AGP_PID" in ''|*[!0-9]*) return 1;; esac
    [ "$(readlink "/proc/$AGP_PID/exe")" = /system/bin/AGPService ] || {
        agp_fail '无法核对 AGP 进程路径；请检查 Root 权限'; return 1;
    }
    AGP_TICKS=$(agp_ticks "$AGP_PID") || { agp_fail 'AGP 进程已退出'; return 1; }
    agp_addresses=$(agp_map_addresses "/proc/$AGP_PID/maps") || {
        agp_fail 'AGP 映射不匹配或不可读；未修改内存'; return 1;
    }
    set -- $agp_addresses
    AGP_BIAS=$1; AGP_ADDR=$2; AGP_GUARD_ADDR=$3
    AGP_BOOT=$(cat /proc/sys/kernel/random/boot_id) || return 1
    [ "$(agp_read "$(agp_mem_path)" "$AGP_GUARD_ADDR" 1 -tu1)" = 1 ] || {
        agp_fail 'AGP 尚未初始化或内存不可读'; return 1;
    }
    agp_code_matches "$AGP_CODE1" "$AGP_LEN1" "$AGP_SIG1" &&
    agp_code_matches "$AGP_CODE2" "$AGP_LEN2" "$AGP_SIG2" &&
    agp_code_matches "$AGP_CODE3" "$AGP_LEN3" "$AGP_SIG3" || {
        agp_fail 'AGP 运行时代码与定位结果不一致；未修改内存'; return 1;
    }
    [ "$(agp_ticks "$AGP_PID")" = "$AGP_TICKS" ] || { agp_fail '校验期间 AGP 已重启'; return 1; }
}
agp_same_identity() {
    IFS=' ' read -r agp_saved_pid agp_saved_ticks agp_saved_bias agp_saved_boot < "$1/identity" || return 1
    agp_identity || return 1
    [ "$AGP_PID" = "$agp_saved_pid" ] && [ "$AGP_TICKS" = "$agp_saved_ticks" ] &&
        [ "$AGP_BIAS" = "$agp_saved_bias" ] && [ "$AGP_BOOT" = "$agp_saved_boot" ] || return 1
    if [ -f "$1/profile" ]; then
        # Recovery must use exactly the same derivation/hash as acquisition.
        cmp -s "$1/profile" "$AGP_PROFILE"
    else
        # Journals from v1.6.7-1.6.9 only ever used this verified fixed layout.
        [ "$AGP_HASH" = "$AGP_KNOWN_HASH" ] && [ "$AGP_FLAG_RVA" = 3420568 ] &&
            [ "$AGP_GUARD_RVA" = 3420864 ]
    fi
}

agp_write() (
    # Open and pin the original process memory before the final identity check.
    exec 6<> "$(agp_mem_path)" || exit 1
    [ "$(agp_ticks "$AGP_PID")" = "$AGP_TICKS" ] || exit 1
    [ "$(agp_read_pinned)" = "$1" ] || exit 1
    case "$2" in
        0) printf '\000';;
        1) printf '\001';;
        *) exit 1;;
    esac | /system/bin/dd of=/proc/self/fd/6 bs=1 seek="$AGP_ADDR" count=1 conv=notrunc status=none 6>&6 || exit 1
    [ "$(agp_read_pinned)" = "$2" ]
)
agp_state() (
    IFS= read -r agp_latest < "$AGP_ROOT/latest" || exit 0
    [ "$agp_latest" = "${1##*/}" ] || exit 0
    printf '%s\n' "$2" > "$1/status.tmp.$$" && mv -f "$1/status.tmp.$$" "$1/status"
)
agp_restore() (
    agp_job=$1
    exec 8> "$AGP_ROOT/write.lock" || exit 1
    flock 8 8>&8 || exit 1
    [ -f "$agp_job/restored" ] && exit 0
    [ -f "$agp_job/identity" ] && [ -f "$agp_job/phase" ] || exit 0
    IFS= read -r agp_phase < "$agp_job/phase"
    if [ "$agp_phase" = prepared ]; then
        echo '没有写入' > "$agp_job/restored"
        agp_state "$agp_job" '尚未申请；没有修改内存'
        exit 0
    fi
    case "$agp_phase" in armed|applied) ;; *) exit 1;; esac
    if ! agp_same_identity "$agp_job"; then
        # A restarted process has lost the old byte. Never write its replacement.
        IFS=' ' read -r agp_old_pid agp_old_ticks agp_old_bias agp_old_boot < "$agp_job/identity"
        if [ "$(cat /proc/sys/kernel/random/boot_id)" != "$agp_old_boot" ] ||
           [ "$(agp_ticks "$agp_old_pid" 2>/dev/null)" != "$agp_old_ticks" ]; then
            echo '原进程已结束；未写入新进程' > "$agp_job/restored"
            agp_state "$agp_job" 'AGP 已重启，旧内存已失效；未写入新进程'
            exit 0
        fi
        agp_state "$agp_job" '恢复校验失败；已保留记录，请检查日志'
        exit 1
    fi
    agp_current=$(agp_read "$(agp_mem_path)" "$AGP_ADDR" 1 -tu1)
    case "$agp_current" in
        0) agp_write 0 1 || {
            agp_state "$agp_job" '恢复写入或回读失败；已保留记录'; exit 1;
        };;
        1) ;; # System already restored the original byte; do not overwrite it.
        *) agp_state "$agp_job" '目标值异常；未覆盖外部修改，已保留记录'; exit 1;;
    esac
    echo '原值 1 已回读确认' > "$agp_job/restored"
    agp_state "$agp_job" '已释放非战斗限制绕过；原值 1 已恢复'
)
agp_listed() {
    awk -v p="$1" '{sub(/#.*/,""); gsub(/^[ \t\r]+|[ \t\r]+$/,""); if($0==p) found=1}
        END {exit !found}' "$BASE/games.list" "$BASE/games.custom.list" || return 1
    ! awk -v p="$1" '{sub(/#.*/,""); gsub(/^[ \t\r]+|[ \t\r]+$/,""); if($0==p) found=1}
        END {exit !found}' "$BASE/games.exclude.list"
}
