(function () {
  'use strict';
  const validPackage = value => typeof value === 'string' && value.length <= 255 && !/[\r\n]/.test(value) && /^[A-Za-z0-9_]+(?:\.[A-Za-z0-9_]+)+$/.test(value);
  function parseSnapshot(text) {
    const rows = new Map();
    let status = '还没有运行记录', running = null, widevine = false, monitor = '', agpEnabled = false, agpStatus = '';
    let apsEnabled = false, apsStatus = '', thermalEnabled = false, thermalStatus = '';
    for (const line of text.split(/\r?\n/)) {
      const [type, pkg, ...rest] = line.split('\t');
      if (type === 'D') { running = pkg === '1'; continue; }
      if (type === 'W') { widevine = pkg === '1'; continue; }
      if (type === 'A') { agpEnabled = pkg === '1'; continue; }
      if (type === 'G') { agpStatus = [pkg, ...rest].join(' '); continue; }
      if (type === 'H') { thermalEnabled = pkg === '1'; continue; }
      if (type === 'Q') { thermalStatus = [pkg, ...rest].join(' '); continue; }
      if (type === 'T') { apsEnabled = pkg === '1'; continue; }
      if (type === 'P') { apsStatus = [pkg, ...rest].join(' '); continue; }
      if (type === 'S') { status = [pkg, ...rest].join(' '); continue; }
      if (type === 'N') { monitor = [pkg, ...rest].join(' '); continue; }
      if (!['B', 'C', 'E', 'I'].includes(type) || !validPackage(pkg)) continue;
      if (!rows.has(pkg)) rows.set(pkg, { pkg, name: pkg, builtin: false, custom: false, excluded: false, installed: false });
      const row = rows.get(pkg);
      if (type === 'B') { row.builtin = true; row.name = rest.join(' ').trim() || pkg; }
      if (type === 'C') row.custom = true;
      if (type === 'E') row.excluded = true;
      if (type === 'I') row.installed = true;
    }
    return { rows, status, running, widevine, monitor, agpEnabled, agpStatus, apsEnabled, apsStatus, thermalEnabled, thermalStatus };
  }
  const enabled = row => (row.builtin || row.custom) && !row.excluded;
  function selectRows(rows, tab, query) {
    const q = query.trim().toLocaleLowerCase();
    return [...rows.values()].filter(row => {
      const inView = tab === 'installed' ? row.installed : tab === 'excluded' ? row.excluded : row.builtin || row.custom;
      return inView && (!q || `${row.name} ${row.pkg}`.toLocaleLowerCase().includes(q));
    }).sort((a, b) => Number(enabled(b)) - Number(enabled(a)) || a.name.localeCompare(b.name, 'zh-CN'));
  }
  const shellQuote = value => "'" + value.replace(/'/g, "'\\''") + "'";
  const moduleDir = () => {
    const path = typeof location !== 'undefined' ? location.pathname : '';
    const match = path.match(/^\/data\/adb\/modules(?:_update)?\/[^/]+/);
    return match ? match[0] : '/data/adb/modules/honor_delta_185';
  };
  function command(op, pkg) {
    if (!['read', 'add', 'remove', 'enable', 'disable', 'wvon', 'wvoff', 'agpon', 'agpoff', 'apson', 'apsoff', 'thermalon', 'thermaloff'].includes(op)) throw new Error('未知操作');
    const base = '/system/bin/sh ' + moduleDir() + '/webui.sh ';
    if (['wvon', 'wvoff', 'agpon', 'agpoff', 'apson', 'apsoff', 'thermalon', 'thermaloff'].includes(op)) return base + op;
    if (op !== 'read' && !validPackage(pkg)) throw new Error('请输入有效的完整包名');
    return base + op + (op === 'read' ? '' : ' ' + shellQuote(pkg));
  }
  function describeAgpStatus(value) {
    const text = String(value || '');
    if (text.includes('自动定位未通过')) return '这个系统版本暂时无法自动识别，原因可在运行详情中查看。';
    if (text.includes('没有可读的 libagp.so')) return '没有找到此策略需要的系统组件。';
    if (text.includes('AGP 进程不存在')) return '等待系统游戏服务启动。';
    if (text.includes('Root 权限') || text.includes('内存不可读')) return '系统服务尚未就绪，或 Root 无法访问，请查看运行详情。';
    if (text.includes('映射不匹配') || text.includes('运行时代码与定位')) return '运行校验没有通过，暂未修改。';
    if (text.includes('这个游戏已从名单关闭')) return '这个游戏已关闭。';
    if (text.includes('固件不支持或游戏已排除')) return '当前系统还没适配，或这个游戏已关闭。';
    if (text.includes('恢复校验失败') || text.includes('恢复写入或回读失败')) return '恢复未完成，请查看运行详情。';
    if (text.includes('目标值异常')) return '系统数据有变化，恢复记录已保留。';
    if (text.includes('原开关不是1')) return '系统当前设置与预期不一致，暂未修改。';
    if (text.includes('AGP 已重启')) return '系统服务已重启，原来的修改已失效。';
    if (text.startsWith('已保持：')) return '已解除限制，实际帧率取决于手机和游戏。';
    if (text.startsWith('已释放非战斗限制绕过')) return '已恢复系统设置。';
    if (text.startsWith('正在校验')) return '正在检查系统是否支持…';
    if (text.startsWith('尚未申请')) return '还没有修改系统设置。';
    if (text === '已关闭') return '已关闭。';
    if (text.includes('已开启，等待')) return '已开启，等待游戏。';
    if (text.startsWith('等待策略')) return '正在准备…';
    if (text.includes('状态读取失败')) return '没能读到状态，点“刷新”重试。';
    if (!text) return '等待游戏。';
    return '暂时无法确认是否生效，请查看运行详情。';
  }
  function monitorStatus(snapshot) {
    const raw = snapshot.status || '';
    const view = (text, note, state) => ({ text, note, state });
    if (snapshot.running === false) return view('自动检测未启动', '名单可以编辑，后台启动后才会生效。', 'error');
    if (snapshot.running !== true) return view('暂时无法确认运行状态', '点“刷新”重新读取。', 'warning');
    if (raw.startsWith('MIGRATION_PENDING')) return view('旧版设置还没清理完', '后台会继续重试，原因可在运行详情中查看。', 'warning');
    if (!snapshot.agpEnabled) return view('解除功能已关闭', '游戏名单会保留。', 'off');
    if (raw.startsWith('SLEEP')) return view('屏幕已关闭', '亮屏后会继续检测游戏。', 'off');
    if (raw.startsWith('BYPASS_OFF')) return view('正在开启解除功能', '等待后台更新状态。', 'waiting');
    if (raw.startsWith('AGP_WAIT')) return view('暂未生效', describeAgpStatus(snapshot.agpStatus), 'warning');
    if (raw.startsWith('AGP_ACTIVE')) {
      if (/context=grace\b/.test(raw)) return view('退出游戏，稍后恢复', '离开游戏约 6 秒后恢复系统设置。', 'waiting');
      const match = raw.match(/package=([A-Za-z0-9_.]+)/);
      const row = match && snapshot.rows && snapshot.rows.get(match[1]);
      const game = row ? row.name : match ? match[1] : '';
      return view('正在为游戏解除限制', game ? `当前游戏：${game}` : '实际帧率取决于手机和游戏。', 'active');
    }
    if (raw.startsWith('READY') || raw.startsWith('IDLE')) return view('等待游戏', '打开名单里已开启的游戏后自动处理。', 'waiting');
    if (raw.startsWith('STOPPED')) return view('自动检测正在停止', '点“刷新”查看最新状态。', 'off');
    return view('暂时无法确认运行状态', '展开运行详情查看具体情况。', 'warning');
  }
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = { validPackage, parseSnapshot, enabled, selectRows, command, describeAgpStatus, monitorStatus };
    return;
  }
  const $ = id => document.getElementById(id);
  let snapshot = { rows: new Map(), status: '' }, tab = 'games', busy = false, connected = false;
  let callbackId = 0;
  const appLabels = new Map();
  let labelsLoading = false;
  function exec(cmd) {
    return new Promise((resolve, reject) => {
      const bridge = window.ksu;
      if (!bridge || typeof bridge.exec !== 'function') {
        reject(new Error('请从 Root 管理器的模块页面打开。管理器需支持模块网页（WebUI）。')); return;
      }
      const id = `honorGamesCallback_${Date.now()}_${++callbackId}`;
      const cleanup = () => { clearTimeout(timer); delete window[id]; };
      const timer = setTimeout(() => { cleanup(); reject(new Error('等待超时，点“刷新”确认是否已保存。')); }, 15000);
      window[id] = (errno, stdout, stderr) => {
        cleanup();
        if (Number(errno) !== 0) reject(new Error(String(stderr || stdout || '操作没成功，请重试。').trim()));
        else resolve(String(stdout || ''));
      };
      try { bridge.exec(cmd, JSON.stringify({ cwd: '/' }), id); }
      catch (error) { cleanup(); reject(error); }
    });
  }
  function message(text, error = false) {
    $('message').textContent = text;
    $('message').className = error ? 'error' : '';
  }
  function setBusy(value) {
    busy = value;
    document.body.classList.toggle('busy', busy);
    $('reload').disabled = busy;
    $('wv-toggle').disabled = busy || !connected;
    $('agp-toggle').disabled = busy || !connected;
    $('thermal-toggle').disabled = busy || !connected;
    $('aps-toggle').disabled = busy || !connected;
    $('package').disabled = busy || !connected;
    $('add-form').querySelector('button').disabled = busy || !connected;
    for (const control of $('list').querySelectorAll('button,input')) control.disabled = busy || !connected;
  }
  function tag(text) {
    const span = document.createElement('span'); span.className = 'tag'; span.textContent = text; return span;
  }
  function render() {
    const all = [...snapshot.rows.values()];
    const games = all.filter(row => row.builtin || row.custom);
    $('count').textContent = `已开启 ${games.filter(enabled).length} / ${games.length}`;
    const rawStatus = snapshot.status;
    $('wv-toggle').checked = snapshot.widevine === true;
    $('agp-toggle').checked = snapshot.agpEnabled === true;
    $('thermal-toggle').checked = snapshot.thermalEnabled === true;
    $('thermal-status').textContent = snapshot.thermalStatus || '正在读取…';
    $('aps-toggle').checked = snapshot.apsEnabled === true;
    $('aps-status').textContent = snapshot.apsStatus || '正在读取…';
    $('agp-status').textContent = !snapshot.agpEnabled ? '已关闭。' : snapshot.running === false ? '等待后台检测程序启动。' : describeAgpStatus(snapshot.agpStatus);
    const state = monitorStatus(snapshot);
    $('status').textContent = state.text;
    $('status-note').textContent = state.note;
    $('summary').dataset.state = state.state;
    $('diagnostics').textContent = [
      `自动检测：${snapshot.running === true ? '运行中' : snapshot.running === false ? '未运行' : '未知'}`,
      `解除功能：${snapshot.agpEnabled ? '开启' : '关闭'}`,
      `Widevine 暂停：${snapshot.widevine ? '开启' : '关闭'}`,
      `运行状态：${rawStatus || '无记录'}`,
      `AGP 状态：${snapshot.agpStatus || '无记录'}`,
      `APS 状态：${snapshot.apsStatus || '无记录'}`,
      `检测方式：${snapshot.monitor || '无记录'}`
    ].join('\n');
    const list = selectRows(snapshot.rows, tab, $('search').value);
    $('result-count').textContent = `${list.length} 项`;
    $('list').replaceChildren(); $('empty').hidden = list.length !== 0;
    for (const row of list) {
      const item = document.createElement('article'); item.className = 'row';
      const details = document.createElement('div'); details.className = 'details';
      const title = document.createElement('div'); title.className = 'title'; title.textContent = row.name;
      details.append(title);
      if (row.name !== row.pkg) {
        const pkg = document.createElement('div'); pkg.className = 'pkg'; pkg.textContent = row.pkg; details.append(pkg);
      }
      const tags = document.createElement('div'); tags.className = 'tags';
      if (row.builtin) tags.append(tag('内置'));
      if (row.custom) tags.append(tag('自定义'));
      if (!row.installed) tags.append(tag('未安装'));
      if (row.excluded) tags.append(tag('已关闭'));
      if (tags.childElementCount) details.append(tags);
      const actions = document.createElement('div'); actions.className = 'row-actions';
      if (row.custom) {
        const remove = document.createElement('button'); remove.type = 'button'; remove.className = 'remove'; remove.textContent = '移除';
        remove.setAttribute('aria-label', `移除自定义游戏 ${row.name}`);
        remove.onclick = () => mutate('remove', row.pkg, '已从名单移除'); actions.append(remove);
      }
      if (!row.builtin && !row.custom && !row.excluded) {
        const add = document.createElement('button'); add.type = 'button'; add.className = 'quiet'; add.textContent = '添加';
        add.onclick = () => mutate('add', row.pkg, '已加入游戏名单'); actions.append(add);
      } else {
        const label = document.createElement('label'); label.className = 'switch';
        const toggle = document.createElement('input'); toggle.type = 'checkbox'; toggle.checked = enabled(row);
        toggle.setAttribute('aria-label', `为 ${row.name} 解除限制`);
        toggle.onchange = () => {
          const op = toggle.checked ? (row.builtin || row.custom ? 'enable' : 'add') : 'disable';
          mutate(op, row.pkg, toggle.checked ? '已开启这个游戏' : '已关闭这个游戏');
        };
        const track = document.createElement('span'); track.className = 'track'; track.setAttribute('aria-hidden', 'true');
        label.append(toggle, track); actions.append(label);
      }
      item.append(details, actions); $('list').append(item);
    }
    setBusy(busy);
  }
  async function read() {
    const text = await exec(command('read'));
    if (!text.split(/\r?\n/).some(line => line.startsWith('B\t'))) throw new Error('游戏名单没读完整，点“刷新”重试。');
    snapshot = parseSnapshot(text); connected = true;
    for (const row of snapshot.rows.values()) {
      if (!row.builtin && appLabels.has(row.pkg)) row.name = appLabels.get(row.pkg);
    }
    render();
    loadLabels();
  }
  async function loadLabels() {
    const bridge = window.ksu;
    if (labelsLoading || !bridge || typeof bridge.getPackagesInfo !== 'function') return;
    labelsLoading = true;
    const names = [...snapshot.rows.values()].filter(row => row.installed && !appLabels.has(row.pkg)).map(row => row.pkg);
    try {
      for (let i = 0; i < names.length; i += 30) {
        try {
          const raw = bridge.getPackagesInfo(JSON.stringify(names.slice(i, i + 30)));
          const info = typeof raw === 'string' ? JSON.parse(raw) : raw;
          if (Array.isArray(info)) for (const app of info) {
            if (validPackage(app.packageName) && typeof app.appLabel === 'string' && app.appLabel) {
              appLabels.set(app.packageName, app.appLabel);
              const row = snapshot.rows.get(app.packageName);
              if (row && !row.builtin) row.name = app.appLabel;
            }
          }
        } catch (_) { /* Package names remain usable when labels are unavailable. */ }
        await new Promise(resolve => setTimeout(resolve, 0));
      }
      render();
    } finally { labelsLoading = false; }
  }
  async function reload() {
    if (busy) return;
    setBusy(true); message('');
    try { await read(); }
    catch (error) {
      connected = false; message(error.message, true);
      $('status').textContent = '没连上模块';
      $('status-note').textContent = '点“刷新”重试，保存过的设置不会丢失。';
      $('summary').dataset.state = 'error';
    }
    finally { setBusy(false); }
  }
  async function mutate(op, pkg, success) {
    if (busy || !connected) return;
    setBusy(true); message('正在保存…');
    try {
      await exec(command(op, pkg));
      await read();
      if (op === 'add') $('package').value = '';
      message(`${success}，已保存。`);
    } catch (error) {
      message(`${error.message} 请刷新查看是否已保存。`, true);
      try { await read(); } catch (_) { connected = false; }
    } finally { render(); setBusy(false); }
  }
  $('reload').onclick = reload;
  $('agp-toggle').onchange = () => {
    const want = $('agp-toggle').checked;
    if (busy || !connected) { $('agp-toggle').checked = !want; return; }
    setBusy(true); message('正在保存…');
    exec(command(want ? 'agpon' : 'agpoff')).then(async () => {
      await read(); message(want ? '已开启，打开名单里的游戏后自动处理。' : '已关闭，恢复情况可在运行详情中查看。');
    }).catch(async error => {
      message(error.message, true);
      try { await read(); } catch (_) { connected = false; }
    }).finally(() => { render(); setBusy(false); });
  };
  $('aps-toggle').onchange = () => {
    const want = $('aps-toggle').checked;
    if (busy || !connected) { $('aps-toggle').checked = !want; return; }
    setBusy(true); message('正在保存…');
    exec(command(want ? 'apson' : 'apsoff')).then(async () => {
      await read();
      message(want ? '已开启，温度允许时会在名单游戏中生效。' : '已关闭，APS 已交回系统。');
    }).catch(async error => {
      message(error.message, true);
      try { await read(); } catch (_) { connected = false; }
    }).finally(() => { render(); setBusy(false); });
  };
  $('thermal-toggle').onchange = () => {
    const want = $('thermal-toggle').checked;
    if (busy || !connected) { $('thermal-toggle').checked = !want; return; }
    setBusy(true); message('正在保存…');
    exec(command(want ? 'thermalon' : 'thermaloff')).then(async () => {
      await read();
      message(want ? '已开启。名单游戏在前台且温度允许时生效。' : '已关闭，下一次温控下发由系统处理。');
    }).catch(async error => {
      message(error.message, true);
      try { await read(); } catch (_) { connected = false; }
    }).finally(() => { render(); setBusy(false); });
  };
  $('wv-toggle').onchange = () => {
    const want = $('wv-toggle').checked;
    if (busy || !connected) { $('wv-toggle').checked = !want; return; }
    setBusy(true); message('正在保存…');
    exec(command(want ? 'wvon' : 'wvoff')).then(async () => {
      await read();
      message(want ? '已开启，游戏时会暂停 Widevine 服务，离开游戏后恢复。' : '已关闭，Widevine 服务已恢复。');
    }).catch(async error => {
      message(`${error.message} 请刷新查看当前设置。`, true);
      try { await read(); } catch (_) { connected = false; }
    }).finally(() => { render(); setBusy(false); });
  };
  $('search').oninput = render;
  document.querySelectorAll('[data-tab]').forEach(button => {
    button.onclick = () => {
      tab = button.dataset.tab;
      document.querySelectorAll('[data-tab]').forEach(other => other.setAttribute('aria-pressed', String(other === button)));
      render();
    };
  });
  $('add-form').onsubmit = event => {
    event.preventDefault(); const pkg = $('package').value.trim();
    if (!validPackage(pkg)) { message('包名格式不对，请填写完整包名，例如 com.tencent.tmgp.dfm。', true); return; }
    mutate('add', pkg, '已加入游戏名单');
  };
  reload();
})();
