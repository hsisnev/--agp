#!/system/bin/sh
# FIFO reads use mksh builtins; idle waits do not spawn a shell poll pipeline.
EVENT_PID=
EVENT_MODE=fallback
EVENT_RETRY=0
FALLBACK_NEXT=0
EVENT_BITS=15
SLEEP_MONITOR=0
# A late-start root service can retain the pre-APEX mount namespace even after
# boot_completed. Clearing LD_* cannot expose libraries absent from that view.
event_runtime_visible() {
    [ -r "$1/apex/com.android.art/lib64/libnativeloader.so" ] ||
    [ -r "$1/apex/com.android.art/lib/libnativeloader.so" ] ||
    [ -r "$1/apex/com.android.runtime/lib64/libnativeloader.so" ] ||
    [ -r "$1/apex/com.android.runtime/lib/libnativeloader.so" ] ||
    [ -r "$1/system/lib64/libnativeloader.so" ] ||
    [ -r "$1/system/lib/libnativeloader.so" ]
}
event_exec() {
    unset LD_LIBRARY_PATH LD_PRELOAD
    export CLASSPATH="$BASE/events.dex"
    set -- /system/bin/app_process -Xmx32m /system/bin agp.AgpEvents "$@"
    if ! event_runtime_visible '' && [ -x /system/bin/nsenter ]; then
        for event_ns_pid in $(/system/bin/pidof system_server 2>/dev/null); do
            case "$event_ns_pid" in ''|*[!0-9]*) continue;; esac
            event_runtime_visible "/proc/$event_ns_pid/root" || continue
            echo "AGP: ART unavailable in launcher mount namespace; using system_server mount namespace pid=$event_ns_pid" >&2
            # Mount namespace only: preserve UID, SELinux domain and helper PID.
            exec /system/bin/nsenter -t "$event_ns_pid" -m -- "$@"
        done
    fi
    exec "$@"
}
event_stop() {
    # Recover a helper left by SIGKILL without signalling an unrelated reused PID.
    event_old_pid=$EVENT_PID
    EVENT_PID=
    if [ -z "$event_old_pid" ] && [ -f "$STATE/events.pid" ]; then
        IFS= read -r event_old_pid < "$STATE/events.pid"
    fi
    case "$event_old_pid" in ''|*[!0-9]*) ;; *)
        event_old_cmd=$(tr '\000' ' ' 2>/dev/null < "/proc/$event_old_pid/cmdline")
        case "$event_old_cmd" in
            *"agp.AgpEvents "*" $BASE "*) EVENT_PID=$event_old_pid;;
        esac;;
    esac
    if [ -n "$EVENT_PID" ]; then
        kill "$EVENT_PID" 2>/dev/null
        wait "$EVENT_PID" 2>/dev/null
    fi
    EVENT_PID=
    exec 7>&-
    rm -f "$STATE/events.fifo" "$STATE/events.pid"
}
event_start() {
    event_stop
    EVENT_MODE=fallback
    event_start_now=$(uptime_seconds)
    EVENT_RETRY=$((event_start_now + 60))
    FALLBACK_NEXT=$((event_start_now + 10))
    if [ -f "$STATE/events.log" ] && [ "$(stat -c %s "$STATE/events.log" 2>/dev/null)" -gt 262144 ]; then
        tail -c 131072 "$STATE/events.log" > "$STATE/events.log.tmp" && mv -f "$STATE/events.log.tmp" "$STATE/events.log"
    fi
    if [ ! -r "$BASE/events.dex" ] || [ ! -x /system/bin/app_process ]; then
        echo 'fallback：缺少 events.dex 或 app_process；10秒核对，60秒重试' > "$STATE/events.status"
        return 1
    fi
    mkfifo -m 600 "$STATE/events.fifo" || {
        echo 'fallback：无法创建事件管道；10秒核对，60秒重试' > "$STATE/events.status"
        return 1
    }
    # O_RDWR prevents EOF/spin while the producer starts or restarts.
    exec 7<> "$STATE/events.fifo"
    (
        event_exec "$STATE/events.fifo" "$BASE" "$STATE" "$$"
    ) 7>&- >> "$STATE/events.log" 2>&1 &
    EVENT_PID=$!
    echo "$EVENT_PID" > "$STATE/events.pid"
    event_ready=0
    # Bound startup time even if a vendor's registration call hangs.
    event_attempt=0
    while [ "$event_attempt" -lt 5 ]; do
        if IFS= read -r -t 1 event_line <&7 2>/dev/null; then
            case "$event_line" in ''|*[!0-9]*) ;; *)
                EVENT_BITS=$((EVENT_BITS | event_line))
                [ $((event_line & 32)) = 0 ] || { event_ready=1; break; };;
            esac
        fi
        kill -0 "$EVENT_PID" 2>/dev/null || break
        event_attempt=$((event_attempt + 1))
    done
    if [ "$event_ready" != 1 ]; then
        event_stop
        echo 'fallback：事件注册失败；10秒核对，60秒重试，见events.log' > "$STATE/events.status"
        log '事件小程序未就绪，降级10秒核对；60秒后重新注册'
        return 1
    fi
    EVENT_MODE=events
    echo 'events：窗口/焦点/显示/设置/文件回调；30秒兜底核对' > "$STATE/events.status"
    log "事件小程序已就绪 pid=$EVENT_PID"
}
event_wait() {
    EVENT_BITS=0
    event_timeout=30
    event_now=$(uptime_seconds)
    event_failed=0
    if [ "$EVENT_MODE" = events ] && ! kill -0 "$EVENT_PID" 2>/dev/null; then
        event_stop
        EVENT_MODE=fallback
        FALLBACK_NEXT=$((event_now + 10))
        event_failed=1
        echo 'fallback：事件进程退出；10秒核对，60秒重试' > "$STATE/events.status"
        log '事件进程退出，降级10秒核对'
    fi
    if [ "$EVENT_MODE" != events ] && [ "$event_now" -ge "$EVENT_RETRY" ] &&
       [ "$CONTEXT" != grace ] && [ "${SLEEP_MONITOR:-0}" != 1 ]; then
        event_start || :
        EVENT_BITS=15
        return
    fi
    if [ "$event_failed" = 1 ]; then EVENT_BITS=15; return; fi
    if [ "${SLEEP_MONITOR:-0}" = 1 ]; then
        if [ "$EVENT_MODE" = events ]; then
            event_timeout=30
        else
            sleep 15
            EVENT_BITS=16
            return
        fi
    fi
    if [ "$EVENT_MODE" != events ]; then
        if [ "$event_now" -ge "$FALLBACK_NEXT" ]; then
            FALLBACK_NEXT=$((event_now + 10))
            EVENT_BITS=15
            return
        fi
        event_timeout=$((FALLBACK_NEXT - event_now))
        [ "$event_timeout" -le 10 ] || event_timeout=10
    fi
    # Renew the AGP 20-second lease at most ten seconds apart; no display polls.
    if [ -n "$TARGET" ] && [ "$event_timeout" -gt 10 ]; then event_timeout=10; fi
    if [ "$CONTEXT" = grace ]; then
        event_remaining=$((EXIT_DEADLINE - $(monotonic_millis)))
        if [ "$event_remaining" -le 0 ]; then return; fi
        if [ "$event_remaining" -lt $((event_timeout * 1000)) ]; then
            event_timeout="$((event_remaining / 1000)).$(printf '%03d' $((event_remaining % 1000)))"
        fi
    fi
    if [ "$EVENT_MODE" = events ]; then
        if IFS= read -r -t "$event_timeout" event_line <&7 2>/dev/null; then
            case "$event_line" in ''|*[!0-9]*) ;; *) EVENT_BITS=$((EVENT_BITS | event_line));; esac
            # Drain a bounded burst. Producer is nonblocking and coalesces at 750ms.
            event_drain=0
            while [ "$event_drain" -lt 64 ] && IFS= read -r -t 0.001 event_line <&7 2>/dev/null; do
                case "$event_line" in ''|*[!0-9]*) ;; *) EVENT_BITS=$((EVENT_BITS | event_line));; esac
                event_drain=$((event_drain + 1))
            done
        fi
    else
        sleep "$event_timeout"
        event_after=$(uptime_seconds)
        if [ "$event_after" -ge "$FALLBACK_NEXT" ]; then
            EVENT_BITS=15
            FALLBACK_NEXT=$((event_after + 10))
        fi
    fi
}
