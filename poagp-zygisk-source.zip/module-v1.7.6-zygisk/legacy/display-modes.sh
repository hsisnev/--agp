#!/system/bin/sh
# Only parse SurfaceFlinger physical mode IDs. DisplayInfo's logical IDs must
# never be passed to the private SurfaceFlinger 1035 transaction.
sf_modes() {
    if [ "${DISPLAY_SNAPSHOT_READY:-0}" = 1 ]; then
        printf '%s' "$DISPLAY_MODE_ROWS"
        return 0
    fi
    awk '
      function val(s, key, v) {
        if (!match(s, key "[[:space:]]*=[[:space:]]*[0-9.]+")) return ""
        v=substr(s,RSTART,RLENGTH); sub(/.*=[[:space:]]*/, "", v); return v
      }
      /mSfDisplayModes[[:space:]]*=/ {section=1}
      section && /DisplayMode[ {]/ && !/mActiveSfDisplayMode[[:space:]]*=/ {
        id=val($0,"id"); w=val($0,"width"); h=val($0,"height")
        hz=val($0,"peakRefreshRate")
        if (hz=="") hz=val($0,"refreshRate")
        if (hz=="") hz=val($0,"fps")
        if (id!="" && w+0>0 && h+0>0 && hz+0>0) print id,w,h,hz
      }
      /mActiveSfDisplayMode[[:space:]]*=/ {exit}
    ' "$STATE/display.txt"
}
sf_active() {
    if [ "${DISPLAY_SNAPSHOT_READY:-0}" = 1 ]; then
        case "$1" in
          id) printf '%s\n' "$DISPLAY_ACTIVE_ID";;
          width) printf '%s\n' "$DISPLAY_ACTIVE_WIDTH";;
          height) printf '%s\n' "$DISPLAY_ACTIVE_HEIGHT";;
          peakRefreshRate) printf '%s\n' "$DISPLAY_ACTIVE_RATE";;
          *) return 1;;
        esac
        return 0
    fi
    awk -v key="$1" '
      function val(s, k, v) {
        if (!match(s, k "[[:space:]]*=[[:space:]]*[0-9.]+")) return ""
        v=substr(s,RSTART,RLENGTH); sub(/.*=[[:space:]]*/, "", v); return v
      }
      /mActiveSfDisplayMode[[:space:]]*=/ {
        v=val($0,key)
        if (key=="peakRefreshRate" && v=="") v=val($0,"refreshRate")
        if (key=="peakRefreshRate" && v=="") v=val($0,"fps")
        if (v!="") {print v; exit}
      }
    ' "$STATE/display.txt"
}
active_id() { sf_active id; }
active_rate() { sf_active peakRefreshRate; }
active_width() { sf_active width; }
active_height() { sf_active height; }
choose_bridge_rate() {
    sf_modes | awk -v w="$(active_width)" -v h="$(active_height)" -v original="$1" -v target="$RATE" '
      $2==w && $3==h {
        a=$4-original; if(a<0)a=-a; b=$4-target; if(b<0)b=-b
        if(a>0.5 && b>0.5) {print $4; found=1; exit}
      }
      END {if(!found) exit 1}
    '
}
