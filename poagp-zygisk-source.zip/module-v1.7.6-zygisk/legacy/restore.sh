#!/system/bin/sh
# Recovery only: never applies a game policy. Called only for existing journals.
PATH=/system/bin:/system/xbin
export PATH
umask 077
BASE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
STATE=/data/local/tmp/honor185-runtime
[ "$(id -u)" = 0 ] || exit 1
[ -d "$STATE" ] && [ ! -L "$STATE" ] && [ "$(stat -c %u "$STATE")" = 0 ] || exit 1
[ -f "$STATE/applied" ] || [ -f "$STATE/aps.before" ] || exit 0
log() { echo "$(date '+%F %T') [旧版清理] $*" >> "$STATE/run.log"; }
boot_id() { cat /proc/sys/kernel/random/boot_id; }
. "$BASE/cache.sh"
. "$BASE/display-modes.sh"
. "$BASE/aps-restore.sh"
read_display() {
    if ! dumpsys display > "$STATE/display.txt"; then
        invalidate_display_cache
        return 1
    fi
    if ! load_display_snapshot; then
        invalidate_display_cache
        return 1
    fi
}
parse_preferred() {
    case "$1" in
      null) PREF_KIND=none; PREF_WIDTH=-1; PREF_HEIGHT=-1; PREF_RATE=0; return 0;;
    esac
    set -- $1
    [ "$#" = 3 ] || return 1
    PREF_WIDTH=$1
    PREF_HEIGHT=$2
    PREF_RATE=$3
    case "$PREF_RATE" in ''|*[!0-9.]*|.*|*.) return 1;; esac
    case "$PREF_RATE" in *.*.*) return 1;; esac
    awk -v r="$PREF_RATE" 'BEGIN {exit !(r ~ /^[0-9]+([.][0-9]+)?$/)}' || return 1
    case "$PREF_WIDTH:$PREF_HEIGHT" in
      -1:-1)
        if awk -v r="$PREF_RATE" 'BEGIN {exit !(r + 0 == 0)}'; then PREF_KIND=none
        else PREF_KIND=refresh_only; fi
        ;;
      *[!0-9:]*|0:*|*:-1|-1:*|*:-|:-*) return 1;;
      *) PREF_KIND=exact;;
    esac
}
preferred_matches() {
    parse_preferred "$1" || return 1
    expected_kind=$PREF_KIND
    expected_width=$PREF_WIDTH
    expected_height=$PREF_HEIGHT
    expected_rate=$PREF_RATE
    parse_preferred "$2" || return 1
    case "$expected_kind:$PREF_KIND" in
      none:none) return 0;;
      refresh_only:refresh_only|refresh_only:exact)
        awk -v a="$expected_rate" -v b="$PREF_RATE" 'BEGIN {exit !((a + 0) == (b + 0))}'
        ;;
      exact:exact)
        [ "$expected_width" = "$PREF_WIDTH" ] &&
        [ "$expected_height" = "$PREF_HEIGHT" ] &&
        awk -v a="$expected_rate" -v b="$PREF_RATE" 'BEGIN {exit !((a + 0) == (b + 0))}'
        ;;
      *) return 1;;
    esac
}
policy_ready() {
    # HONOR AGP legitimately supplies policies that differ from AOSP DMD.
    # Require the debug flag to be cleared and the preferred-mode bridge gone.
    grep -q '^debugDisplayModeSetByBackdoor=0$' "$STATE/sf.txt" || return 1
    nowpref=$(cmd display get-user-preferred-display-mode 0 | sed 's/^User preferred display mode: //')
    preferred_matches "$pref" "$nowpref" || return 1
    # Unless normal SF policy was already fixed at our target, reject a stale
    # target-only policy left by 1035. Do not assume DMD == vendor AGP policy.
    line=$(grep 'displayManagerPolicy=' "$STATE/sf.txt" | head -n 1)
    [ -n "$line" ] || return 1
    # Recovery can run before auto-selection. Check the old written target,
    # not the new request (e.g. recover 120Hz before selecting a new 185 cap).
    release_rate=$(awk -v r="$wanted" 'BEGIN {printf "%.2f", r+0}')
    target_fixed="physical=[$release_rate Hz, $release_rate Hz]"
    if echo "$line" | grep -F "$target_fixed" >/dev/null; then
        [ -f "$STATE/normal-policy.before" ] &&
        grep -F "$target_fixed" "$STATE/normal-policy.before" >/dev/null || return 1
    fi
    return 0
}

restore() {
    aps_restore || { log "APS 恢复失败，保留记录等待重试"; return 1; }
    # Nothing was applied - there is no override to release and no bridge
    # transaction to run. This must succeed even on devices whose display
    # modes make bridge selection impossible.
    [ -f "$STATE/applied" ] || return 0
    # Settings persist over reboot; SF mode IDs are restored only within the same boot.
    wanted=$(cat "$STATE/written")
    for key in min peak; do
        now=$(settings get system "${key}_refresh_rate")
        if [ "$now" = "$wanted" ]; then
            old=$(cat "$STATE/$key.before")
            if [ "$old" = null ]; then
                settings delete system "${key}_refresh_rate" >/dev/null || return 1
            else
                settings put system "${key}_refresh_rate" "$old" || return 1
            fi
        else
            log "$key 已被其他程序修改，保留其当前值 $now"
        fi
    done
    # 1035(-1) intentionally returns BAD_VALUE but clears the debug flag first.
    # Never treat its return value as proof of release: inspect SF itself.
    service call SurfaceFlinger 1035 i32 -1 > "$STATE/release.reply" 2>&1
    dumpsys SurfaceFlinger > "$STATE/sf.txt"
    grep -q '^debugDisplayModeSetByBackdoor=0$' "$STATE/sf.txt" || {
        log '清除手动标志失败，保留备份'; return 1;
    }
    # 1035 replaced SF's display-manager policy too. Force a NORMAL DMD
    # transaction by temporarily changing then restoring the preferred mode.
    # The bridge is not a 1035 fixed-mode request and is immediately reverted.
    if ! dumpsys power | grep 'mWakefulness=Awake' > /dev/null; then
        touch "$STATE/sleep.release.ready"
        echo 'PENDING_RELEASE：已恢复设置并清除手动标志；等待亮屏重新下发正常策略。' > "$STATE/status"
        return 0
    fi
    rm -f "$STATE/sleep.release.ready"
    pref=$(cmd display get-user-preferred-display-mode 0 | sed 's/^User preferred display mode: //')
    if [ -f "$STATE/releasing" ]; then pref=$(cat "$STATE/preferred.release"); fi
    parse_preferred "$pref" || { log '显示偏好格式错误'; return 1; }
    saved_kind=$PREF_KIND
    saved_rate=$PREF_RATE
    saved_width=$PREF_WIDTH
    saved_height=$PREF_HEIGHT
    echo "$pref" > "$STATE/preferred.release"
    touch "$STATE/releasing"
    read_display || return 1
    bridge=$(choose_bridge_rate "$saved_rate") || {
        # No intermediate mode to bridge with. If our settings override and
        # the manual flag are already clear, the release is effectively done -
        # SurfaceFlinger just needs the next normal policy transaction, which
        # the system will issue on its own. Keep 'applied' so policy_ready
        # verification still runs below.
        log '找不到桥接刷新率；若手动标志已清除则跳过桥接直接验证'
        bridge=skip
    }
    if [ "$bridge" != skip ]; then
        bridge_width=$(active_width)
        bridge_height=$(active_height)
        case "$bridge_width:$bridge_height" in
          ''|*[!0-9:]*|0:*|*:0) log '无法读取当前显示分辨率'; return 1;;
        esac
        cmd display set-user-preferred-display-mode "$bridge_width" "$bridge_height" "$bridge" 0 || return 1
        sleep 1
    fi
    case "$saved_kind" in
      none) cmd display clear-user-preferred-display-mode 0 || return 1;;
      refresh_only)
        set -- $(cat "$STATE/resolution.before")
        [ "$#" = 2 ] || { log '无法读取原显示分辨率'; return 1; }
        cmd display set-user-preferred-display-mode "$1" "$2" "$saved_rate" 0 || return 1
        ;;
      exact)
        cmd display set-user-preferred-display-mode "$saved_width" "$saved_height" "$saved_rate" 0 || return 1
        ;;
    esac
    rm -f "$STATE/releasing"
    sleep 1
    dumpsys SurfaceFlinger > "$STATE/sf.txt"
    grep -q '^debugDisplayModeSetByBackdoor=0$' "$STATE/sf.txt" || return 1
    attempt=0
    until policy_ready; do
        attempt=$((attempt + 1))
        [ "$attempt" -lt 5 ] || break
        sleep 1
        dumpsys SurfaceFlinger > "$STATE/sf.txt"
    done
    if ! policy_ready; then
        echo 'PENDING_RELEASE：尚未确认手动覆盖已清除，保留备份继续恢复。' > "$STATE/status"
        log '覆盖释放尚未回读确认；保留applied标记'
        return 0
    fi
    rm -f "$STATE/applied"
    log '已验证手动标志为0、显示偏好复原且无残留目标固定策略；未恢复固定模式ID'

}

# The saved target is for residue detection/bridge selection only.
RATE=$(cat "$STATE/written" 2>/dev/null)
RATE=${RATE%.0}
restore || exit 1
[ ! -f "$STATE/applied" ] && [ ! -f "$STATE/aps.before" ] || exit 3
