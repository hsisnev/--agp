#!/system/bin/sh
clear_display_snapshot() {
    DISPLAY_SNAPSHOT_READY=0
    DISPLAY_ACTIVE_ID=
    DISPLAY_ACTIVE_WIDTH=
    DISPLAY_ACTIVE_HEIGHT=
    DISPLAY_ACTIVE_RATE=
    DISPLAY_MODE_ROWS=
}
invalidate_display_cache() {
    clear_display_snapshot
    TARGET_MODE_KEY=
}
load_display_snapshot() {
    clear_display_snapshot
    awk '
      function value(text, key, result) {
        if (!match(text, key "[[:space:]]*=[[:space:]]*[0-9.]+")) return ""
        result=substr(text,RSTART,RLENGTH); sub(/.*=[[:space:]]*/, "", result); return result
      }
      function rate(text, result) {
        result=value(text,"peakRefreshRate")
        if(result=="") result=value(text,"refreshRate")
        if(result=="") result=value(text,"fps")
        return result
      }
      /mSfDisplayModes[[:space:]]*=/ {section=1}
      section && /DisplayMode[ {]/ && !/mActiveSfDisplayMode[[:space:]]*=/ {
        id=value($0,"id"); width=value($0,"width"); height=value($0,"height"); hz=rate($0)
        if(id!="" && width+0>0 && height+0>0 && hz+0>0) print "M",id,width,height,hz
      }
      /mActiveSfDisplayMode[[:space:]]*=/ {
        id=value($0,"id"); width=value($0,"width"); height=value($0,"height"); hz=rate($0)
        if(id!="" && width+0>0 && height+0>0 && hz+0>0) print "A",id,width,height,hz
        exit
      }
    ' "$STATE/display.txt" > "$STATE/display.parsed" || return 1
    while read -r row_type row_id row_width row_height row_rate; do
        case "$row_type" in
          M) DISPLAY_MODE_ROWS="$DISPLAY_MODE_ROWS$row_id $row_width $row_height $row_rate
";;
          A) DISPLAY_ACTIVE_ID=$row_id
             DISPLAY_ACTIVE_WIDTH=$row_width
             DISPLAY_ACTIVE_HEIGHT=$row_height
             DISPLAY_ACTIVE_RATE=$row_rate;;
        esac
    done < "$STATE/display.parsed"
    [ -n "$DISPLAY_ACTIVE_ID" ] && [ -n "$DISPLAY_MODE_ROWS" ] || return 1
    DISPLAY_SNAPSHOT_READY=1
}
