#!/system/bin/sh
# Private ABI verified from this phone's android.aps.IHwApsManager.Stub DEX.
# getDynamicFps(String): int = 29; setDynamicFps(String,int): int = 28.
aps_reply_int() {
    aps_hex=$(printf '%s\n' "$1" | sed -n "s/.*Parcel([[:space:]]*00000000[[:space:]]\([0-9a-fA-F]\{8\}\)[[:space:]].*/\1/p")
    [ ${#aps_hex} = 8 ] || return 1
    aps_num=$((0x$aps_hex))
    [ "$aps_num" -lt 2147483648 ] || aps_num=$((aps_num - 4294967296))
    echo "$aps_num"
}
aps_get() { aps_reply_int "$(service call aps_service 29 s16 "$1" 2>&1)"; }
aps_set() {
    aps_ret=$(aps_reply_int "$(service call aps_service 28 s16 "$1" i32 "$2" 2>&1)") || return 1
    [ "$aps_ret" = 0 ]
}
aps_valid_pkg() {
    printf '%s\n' "$1" | grep -Eq '^[A-Za-z0-9_]+(\.[A-Za-z0-9_]+)+$'
}
aps_restore() {
    [ -f "$STATE/aps.before" ] || return 0
    read -r aps_pkg aps_old aps_written aps_boot < "$STATE/aps.before"
    aps_valid_pkg "$aps_pkg" || return 1
    # Dynamic APS state is per boot. Never replay a previous boot's value.
    if [ "$aps_boot" = "$(boot_id)" ]; then
        aps_now=$(aps_get "$aps_pkg") || return 1
        if [ "$aps_now" = "$aps_written" ]; then
            aps_set "$aps_pkg" "$aps_old" || return 1
            [ "$(aps_get "$aps_pkg")" = "$aps_old" ] || return 1
            log "APS 恢复：$aps_pkg $aps_old"
        else
            log "APS 已被系统修改，保留：$aps_pkg $aps_now"
        fi
    fi
    rm -f "$STATE/aps.before"
}
