package org.poagp.zygisk;

import android.app.Application;
import android.content.Context;
import android.os.Build;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.Log;
import java.io.FileInputStream;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.security.MessageDigest;
import java.util.Map;

public final class ThermalHook {
    private static final String PACKAGE = "com.hihonor.android.hnaps";
    private static final String APK = "/system/app/HnAps/HnAps.apk";
    private static final String APK_HASH = "6388d529a953505496e5bd5e82696b63e844f48055fca244ab56ddacb1f85e15";
    private static final String BUILD = "HONOR/AAK-AN00/HNAAK:16/HONORAAK-AN00/10DLDLD175C00E170:user/release-keys";
    private static final String KEY = "poagp_zygisk90_game_lease";
    private static final String TAG = "PoAGPZygisk";
    private final ThreadLocal<String> game = new ThreadLocal<String>();
    private final Field contextField;
    private Method temperatureBackup;
    private Method targetBackup;
    private volatile boolean enabled;
    private String lastHitPackage;

    private ThermalHook(Field contextField) { this.contextField = contextField; }

    private static native boolean prepare();
    private static native Method hook(Method target, ThermalHook self, Method callback);
    private static native boolean deoptimize(Method target);

    public static boolean install(Application app) throws Exception {
        if (!BUILD.equals(Build.FINGERPRINT)) return false;
        Context context = PACKAGE.equals(app.getPackageName()) ? app
                : app.createPackageContext(PACKAGE, Context.CONTEXT_INCLUDE_CODE);
        if (!APK.equals(context.getApplicationInfo().sourceDir) || !apkVerified()) return false;
        Class<?> adapter = Class.forName(PACKAGE + ".ApsAGPAdapter", false, context.getClassLoader());
        Method temperature = adapter.getDeclaredMethod("setGameFpsByTemp", String.class, boolean.class);
        Method target = adapter.getDeclaredMethod("getTargetFpsBaseMaxFps", int.class, Map.class);
        Field field = adapter.getDeclaredField("sContext");
        if (Modifier.isStatic(temperature.getModifiers()) || Modifier.isStatic(target.getModifiers())
                || !Modifier.isStatic(field.getModifiers()) || temperature.getReturnType() != void.class
                || target.getReturnType() != int.class) return false;
        field.setAccessible(true);
        return prepare() && new ThermalHook(field).installHooks(temperature, target);
    }

    private static boolean apkVerified() throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        try (FileInputStream file = new FileInputStream(APK)) {
            byte[] buffer = new byte[8192];
            int count;
            while ((count = file.read(buffer)) != -1) digest.update(buffer, 0, count);
        }
        StringBuilder hash = new StringBuilder(64);
        final String digits = "0123456789abcdef";
        for (byte value : digest.digest()) {
            hash.append(digits.charAt((value & 0xff) >>> 4));
            hash.append(digits.charAt(value & 0x0f));
        }
        return APK_HASH.contentEquals(hash);
    }

    private synchronized boolean installHooks(Method temperature, Method target) throws Exception {
        Method onTarget = ThermalHook.class.getMethod("onTarget", Object[].class);
        Method onTemperature = ThermalHook.class.getMethod("onTemperature", Object[].class);
        if (!deoptimize(temperature)) return false;
        targetBackup = hook(target, this, onTarget);
        if (targetBackup == null) return false;
        targetBackup.setAccessible(true);
        temperatureBackup = hook(temperature, this, onTemperature);
        if (temperatureBackup != null) temperatureBackup.setAccessible(true);
        enabled = temperatureBackup != null;
        return enabled;
    }

    private static Object original(Method backup, Object[] args) throws Throwable {
        try {
            return backup.invoke(args[0], args[1], args[2]);
        } catch (InvocationTargetException wrapped) {
            throw wrapped.getCause();
        }
    }

    public Object onTemperature(Object[] args) throws Throwable {
        Method backup;
        synchronized (this) { backup = temperatureBackup; }
        String previous = game.get();
        game.set(Boolean.TRUE.equals(args[2]) ? (String) args[1] : null);
        try {
            return original(backup, args);
        } finally {
            if (previous == null) game.remove();
            else game.set(previous);
        }
    }

    public Object onTarget(Object[] args) throws Throwable {
        Method backup;
        synchronized (this) { backup = targetBackup; }
        Object result = original(backup, args);
        String pkg = game.get();
        if (!enabled || pkg == null || !Integer.valueOf(90).equals(result)) return result;
        try {
            String lease = validLease((Context) contextField.get(null), pkg);
            if (lease == null) return result;
            synchronized (this) {
                if (!pkg.equals(lastHitPackage)) {
                    lastHitPackage = pkg;
                    Log.i(TAG, "hook.hit.v176 " + pkg);
                }
            }
            return Integer.valueOf(0);
        } catch (Exception unreadable) {
            return result;
        }
    }

    private static String validLease(Context context, String pkg) throws Exception {
        if (context == null) return null;
        String lease = Settings.Global.getString(context.getContentResolver(), KEY);
        if (lease == null || lease.length() > 280) return null;
        String[] fields = lease.split(":", -1);
        if (fields.length != 3 || !fields[2].equals(pkg)) return null;
        int boot = Settings.Global.getInt(context.getContentResolver(), "boot_count", -1);
        long now = SystemClock.elapsedRealtime() / 1000;
        long expiry = Long.parseLong(fields[1]);
        if (boot < 0 || Integer.parseInt(fields[0]) != boot || expiry <= now || expiry > now + 12) return null;
        Object power = context.getSystemService(Context.POWER_SERVICE);
        if (power == null) return null;
        int status = (Integer) power.getClass().getMethod("getCurrentThermalStatus").invoke(power);
        return status >= 0 && status < 5 ? lease : null;
    }
}
