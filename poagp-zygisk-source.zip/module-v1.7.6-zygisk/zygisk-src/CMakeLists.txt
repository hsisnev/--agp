cmake_minimum_required(VERSION 3.28)
project(poagp_zygisk LANGUAGES C CXX ASM)

if(NOT ANDROID OR NOT ANDROID_ABI STREQUAL "arm64-v8a")
    message(FATAL_ERROR "Use the Android NDK toolchain with ANDROID_ABI=arm64-v8a")
endif()
if(NOT EXISTS "${HOOK_DEX_DIR}/hook_dex.hpp")
    message(FATAL_ERROR "Run build-dex.py and provide -DHOOK_DEX_DIR=...")
endif()

set(CMAKE_POSITION_INDEPENDENT_CODE ON)
set(CMAKE_CXX_STANDARD 23)
set(LSPLANT_BUILD_SHARED OFF CACHE BOOL "" FORCE)
set(LSPLANT_STANDALONE OFF CACHE BOOL "" FORCE)
add_subdirectory("${LSPLANT_DIR}/lsplant/src/main/jni" lsplant)

# Embed ShadowHook in the module so the app linker loads just one library.
set(SHADOW "${SHADOWHOOK_DIR}/shadowhook/src/main/cpp")
file(GLOB SHADOW_SOURCES CONFIGURE_DEPENDS "${SHADOW}/*.c" "${SHADOW}/arch/arm64/*.c"
    "${SHADOW}/arch/arm64/*.S" "${SHADOW}/common/*.c" "${SHADOW}/third_party/*/*.c")
add_library(poagp_shadowhook STATIC ${SHADOW_SOURCES})
target_compile_features(poagp_shadowhook PRIVATE c_std_11)
target_include_directories(poagp_shadowhook PUBLIC "${SHADOW}/include" PRIVATE "${SHADOW}"
    "${SHADOW}/arch/arm64" "${SHADOW}/common" "${SHADOW}/third_party/xdl"
    "${SHADOW}/third_party/bsd" "${SHADOW}/third_party/lss")

add_library(poagp SHARED module.cpp)
target_include_directories(poagp PRIVATE "${HOOK_DEX_DIR}")
target_compile_options(poagp PRIVATE -fvisibility=hidden)
target_link_libraries(poagp PRIVATE lsplant_static poagp_shadowhook log dl)
target_link_options(poagp PRIVATE -Wl,--exclude-libs,ALL -Wl,-z,defs -Wl,-z,max-page-size=16384
    "-Wl,--version-script=${CMAKE_CURRENT_SOURCE_DIR}/exports.map")
set_target_properties(poagp PROPERTIES PREFIX "" OUTPUT_NAME "arm64-v8a")
