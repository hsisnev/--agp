# 构建破-AGP v1.7.6 Zygisk

从 `honor185` 目录执行。开发机需要 Android SDK Platform 35、Build Tools 35.0.0、NDK `29.0.14206865`、CMake 3.28 或更新版本、Ninja 和 JDK。`ANDROID_SDK_ROOT` 指向已有的 SDK。此版本目标为 ARM64。

```bash
build_dir="$PWD/zygisk-build-v1.7.6"
src="$PWD/module-v1.7.6-zygisk/zygisk-src"
ndk="$ANDROID_SDK_ROOT/ndk/29.0.14206865"
mkdir -p "$build_dir"
git clone https://github.com/JingMatrix/LSPlant.git "$build_dir/lsplant"
git -C "$build_dir/lsplant" checkout 7a768e31ffb2852797631b5140b54f9702a78743
git -C "$build_dir/lsplant" submodule update --init --recursive lsplant/src/main/jni/external/dex_builder
git clone https://github.com/bytedance/android-inline-hook.git "$build_dir/shadowhook"
git -C "$build_dir/shadowhook" checkout 854c775c2c3676e57a0f383597ebf420b5204161
python "$src/build-dex.py" "$build_dir/generated/hook_dex.hpp" --sdk "$ANDROID_SDK_ROOT"
cmake -G Ninja -S "$src" -B "$build_dir/native" \
  -DCMAKE_TOOLCHAIN_FILE="$ndk/build/cmake/android.toolchain.cmake" \
  -DANDROID_ABI=arm64-v8a -DANDROID_PLATFORM=android-35 -DANDROID_STL=c++_static \
  -DLSPLANT_DIR="$build_dir/lsplant" -DSHADOWHOOK_DIR="$build_dir/shadowhook" \
  -DHOOK_DEX_DIR="$build_dir/generated" -DCMAKE_BUILD_TYPE=Release
cmake --build "$build_dir/native" --target poagp
python build-v1.7.6-zygisk.py "$build_dir/native/arm64-v8a.so"
```

分发构建产物时随附上游许可文本和与二进制对应的源码及构建材料，按 LSPlant 的 LGPL 条款提供重新链接所需的文件。

真机验证应先看到 `PoAGPZygisk` 的 `hook.ready.v176`，再确认名单内游戏触发 90 限制时出现 `hook.hit.v176` 且 AGP 收到原有解除通知。还需确认离开游戏、排除名单、紧急温控和无有效温度读数时继续走荣耀原流程。
