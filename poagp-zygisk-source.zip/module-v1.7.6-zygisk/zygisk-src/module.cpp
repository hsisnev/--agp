#include <sys/types.h>
#include "zygisk.hpp"
#include "hook_dex.hpp"
#include <android/log.h>
#include <elf.h>
#include <fcntl.h>
#include <link.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/system_properties.h>
#include <unistd.h>
#include <atomic>
#include <cstring>
#include <string_view>
#include <unordered_map>
#include <lsplant.hpp>
#include <shadowhook.h>

namespace {
constexpr char kTag[] = "PoAGPZygisk";
constexpr char kFingerprint[] = "HONOR/AAK-AN00/HNAAK:16/HONORAAK-AN00/10DLDLD175C00E170:user/release-keys";
constexpr char kProcess[] = "com.hihonor.iaware";
void (*original_poll)(JNIEnv*, jobject, jlong, jint);
std::atomic_bool attempted{false};
bool first_poll_logged = false; // Only accessed on the main thread.
bool waiting_app_logged = false;

void diagnostic(const char* stage) {
    __android_log_write(ANDROID_LOG_INFO, kTag, stage);
}

class ArtSymbols {
public:
    bool open() {
        return dl_iterate_phdr([](dl_phdr_info* info, size_t, void* arg) -> int {
            std::string_view path(info->dlpi_name);
            auto* self = static_cast<ArtSymbols*>(arg);
            if (!path.starts_with("/apex/com.android.art/") || !path.ends_with("/libart.so")) return 0;
            self->bias = info->dlpi_addr;
            int fd = ::open(info->dlpi_name, O_RDONLY | O_CLOEXEC);
            if (fd < 0) return 1;
            struct stat st{};
            if (!fstat(fd, &st) && st.st_size >= static_cast<off_t>(sizeof(Elf64_Ehdr)) && st.st_size < 64 * 1024 * 1024) {
                self->size = st.st_size;
                void* data = mmap(nullptr, self->size, PROT_READ, MAP_PRIVATE, fd, 0);
                if (data != MAP_FAILED) self->bytes = static_cast<const char*>(data);
            }
            close(fd);
            return 1;
        }, this) && bytes;
    }

    void* find(std::string_view wanted, bool prefix) const {
        const auto* header = at<Elf64_Ehdr>(0, 1);
        if (!header || memcmp(header->e_ident, ELFMAG, SELFMAG) || header->e_machine != EM_AARCH64
                || header->e_ident[EI_CLASS] != ELFCLASS64 || header->e_ident[EI_DATA] != ELFDATA2LSB
                || header->e_shentsize != sizeof(Elf64_Shdr)) return nullptr;
        const auto* sections = at<Elf64_Shdr>(header->e_shoff, header->e_shnum);
        if (!sections) return nullptr;
        void* match = nullptr;
        for (size_t i = 0; i < header->e_shnum; ++i) {
            const auto& section = sections[i];
            if ((section.sh_type != SHT_SYMTAB && section.sh_type != SHT_DYNSYM)
                    || section.sh_link >= header->e_shnum || section.sh_entsize != sizeof(Elf64_Sym)) continue;
            const auto& strings = sections[section.sh_link];
            const auto* names = at<char>(strings.sh_offset, strings.sh_size);
            size_t count = section.sh_size / sizeof(Elf64_Sym);
            const auto* symbols = at<Elf64_Sym>(section.sh_offset, count);
            if (!names || !symbols) continue;
            for (size_t index = 0; index < count; ++index) {
                const auto& entry = symbols[index];
                if (!entry.st_value || entry.st_shndx >= header->e_shnum || entry.st_shndx == SHN_UNDEF
                        || !(sections[entry.st_shndx].sh_flags & SHF_ALLOC) || entry.st_name >= strings.sh_size) continue;
                const char* begin = names + entry.st_name;
                const char* end = static_cast<const char*>(memchr(begin, 0, strings.sh_size - entry.st_name));
                if (!end) continue;
                std::string_view name(begin, end - begin);
                auto* address = reinterpret_cast<void*>(bias + entry.st_value);
                if (name == wanted) return address;
                if (prefix && name.starts_with(wanted) && !match) match = address;
            }
        }
        return match;
    }

private:
    template<class T> const T* at(size_t offset, size_t count) const {
        if (!bytes || offset > size || count > (size - offset) / sizeof(T)) return nullptr;
        return reinterpret_cast<const T*>(bytes + offset);
    }
    const char* bytes{};
    size_t size{};
    uintptr_t bias{};
};

ArtSymbols art;
std::unordered_map<void*, void*> inline_hooks;

void* inline_hook(void* target, void* replacement) {
    void* original = nullptr;
    void* stub = shadowhook_hook_func_addr(target, replacement, &original);
    if (!stub) return nullptr;
    inline_hooks.emplace(target, stub);
    return original;
}

bool inline_unhook(void* target) {
    auto found = inline_hooks.find(target);
    if (found == inline_hooks.end() || shadowhook_unhook(found->second) != 0) return false;
    inline_hooks.erase(found);
    return true;
}

jobject native_hook(JNIEnv* env, jclass, jobject target, jobject self, jobject callback) {
    return lsplant::Hook(env, target, self, callback);
}

jboolean native_deoptimize(JNIEnv* env, jclass, jobject target) {
    return lsplant::Deoptimize(env, target);
}

bool clear_exception(JNIEnv* env) {
    if (!env->ExceptionCheck()) return false;
    env->ExceptionClear();
    return true;
}

jboolean native_prepare(JNIEnv* env, jclass) {
    if (!art.open()) {
        diagnostic("diag.art-file-failed");
        return false;
    }
    if (shadowhook_init(SHADOWHOOK_MODE_UNIQUE, false) != 0) {
        diagnostic("diag.shadowhook-failed");
        return false;
    }
    lsplant::InitInfo info{
        .inline_hooker = inline_hook,
        .inline_unhooker = inline_unhook,
        .art_symbol_resolver = [](std::string_view name) { return art.find(name, false); },
        .art_symbol_prefix_resolver = [](std::string_view name) { return art.find(name, true); },
    };
    if (!lsplant::Init(env, info) || clear_exception(env)) {
        diagnostic("diag.lsplant-failed");
        return false;
    }
    diagnostic("diag.lsplant-ready");
    return JNI_TRUE;
}

bool install(JNIEnv* env, jobject app) {
    jclass loader_class = env->FindClass("java/lang/ClassLoader");
    if (clear_exception(env) || !loader_class) return false;
    jmethodID system_loader = env->GetStaticMethodID(loader_class, "getSystemClassLoader", "()Ljava/lang/ClassLoader;");
    jmethodID load_class = env->GetMethodID(loader_class, "loadClass", "(Ljava/lang/String;)Ljava/lang/Class;");
    if (clear_exception(env) || !system_loader || !load_class) return false;
    jobject parent = env->CallStaticObjectMethod(loader_class, system_loader);
    if (clear_exception(env) || !parent) return false;
    jclass memory_loader = env->FindClass("dalvik/system/InMemoryDexClassLoader");
    if (clear_exception(env) || !memory_loader) return false;
    jmethodID ctor = env->GetMethodID(memory_loader, "<init>", "(Ljava/nio/ByteBuffer;Ljava/lang/ClassLoader;)V");
    if (clear_exception(env) || !ctor) return false;
    jobject dex = env->NewDirectByteBuffer(const_cast<unsigned char*>(kHookDex), sizeof(kHookDex));
    if (clear_exception(env) || !dex) return false;
    jobject loader = env->NewObject(memory_loader, ctor, dex, parent);
    if (clear_exception(env) || !loader) return false;
    jstring name = env->NewStringUTF("org.poagp.zygisk.ThermalHook");
    if (clear_exception(env) || !name) return false;
    auto hook_class = static_cast<jclass>(env->CallObjectMethod(loader, load_class, name));
    if (clear_exception(env) || !hook_class) return false;
    const JNINativeMethod methods[] = {
        {"prepare", "()Z", reinterpret_cast<void*>(native_prepare)},
        {"hook", "(Ljava/lang/reflect/Method;Lorg/poagp/zygisk/ThermalHook;Ljava/lang/reflect/Method;)Ljava/lang/reflect/Method;", reinterpret_cast<void*>(native_hook)},
        {"deoptimize", "(Ljava/lang/reflect/Method;)Z", reinterpret_cast<void*>(native_deoptimize)},
    };
    jint registered = env->RegisterNatives(hook_class, methods, sizeof(methods) / sizeof(methods[0]));
    if (clear_exception(env) || registered != JNI_OK) return false;
    diagnostic("diag.dex-ready");
    jmethodID start = env->GetStaticMethodID(hook_class, "install", "(Landroid/app/Application;)Z");
    if (clear_exception(env) || !start) return false;
    bool installed = env->CallStaticBooleanMethod(hook_class, start, app);
    return !clear_exception(env) && installed;
}

void try_install(JNIEnv* env) {
    if (env->PushLocalFrame(32) != JNI_OK) {
        clear_exception(env);
        return;
    }
    jclass thread = env->FindClass("android/app/ActivityThread");
    jmethodID current = thread ? env->GetStaticMethodID(thread, "currentApplication", "()Landroid/app/Application;") : nullptr;
    if (!clear_exception(env) && current) {
        jobject app = env->CallStaticObjectMethod(thread, current);
        if (!clear_exception(env) && app) {
            attempted = true;
            diagnostic("diag.application-ready");
            bool ready = install(env, app);
            clear_exception(env);
            __android_log_write(ready ? ANDROID_LOG_INFO : ANDROID_LOG_ERROR, kTag,
                                ready ? "hook.ready.v176" : "hook.failed.v176");
        } else if (!waiting_app_logged) {
            waiting_app_logged = true;
            diagnostic("diag.application-pending");
        }
    } else {
        attempted = true;
        __android_log_write(ANDROID_LOG_ERROR, kTag, "hook.bootstrap-failed.v176");
    }
    env->PopLocalFrame(nullptr);
}

void poll(JNIEnv* env, jobject queue, jlong ptr, jint millis) {
    original_poll(env, queue, ptr, millis);
    if (attempted.load(std::memory_order_relaxed) || getpid() != gettid() || env->ExceptionCheck()) return;
    if (!first_poll_logged) {
        first_poll_logged = true;
        diagnostic("diag.main-poll");
    }
    try_install(env);
}

class Module final : public zygisk::ModuleBase {
public:
    void onLoad(zygisk::Api* api, JNIEnv* env) override { api_ = api; env_ = env; }
    void preAppSpecialize(zygisk::AppSpecializeArgs* args) override {
        char build[PROP_VALUE_MAX]{};
        const char* name = args->nice_name ? env_->GetStringUTFChars(args->nice_name, nullptr) : nullptr;
        bool target = name && !strcmp(name, kProcess);
        if (name) env_->ReleaseStringUTFChars(args->nice_name, name);
        clear_exception(env_);
        __system_property_get("ro.build.fingerprint", build);
        if (target) diagnostic("diag.target-entry");
        if (target && build == std::string_view(kFingerprint)) {
            JNINativeMethod method{"nativePollOnce", "(JI)V", reinterpret_cast<void*>(poll)};
            api_->hookJniNativeMethods(env_, "android/os/MessageQueue", &method, 1);
            original_poll = reinterpret_cast<decltype(original_poll)>(method.fnPtr);
            clear_exception(env_);
            diagnostic(original_poll ? "diag.jni-ready" : "diag.jni-unavailable");
            if (original_poll) return;
        } else if (target) {
            diagnostic("diag.firmware-mismatch");
        }
        api_->setOption(zygisk::Option::DLCLOSE_MODULE_LIBRARY);
    }
    void postAppSpecialize(const zygisk::AppSpecializeArgs*) override {
        if (original_poll) diagnostic("diag.target-post");
    }
    void preServerSpecialize(zygisk::ServerSpecializeArgs*) override {
        api_->setOption(zygisk::Option::DLCLOSE_MODULE_LIBRARY);
    }
private:
    zygisk::Api* api_{};
    JNIEnv* env_{};
};
}
REGISTER_ZYGISK_MODULE(Module)
