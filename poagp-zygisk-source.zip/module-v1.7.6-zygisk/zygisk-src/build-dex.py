"""Compile ThermalHook.java into a header embedded in the only native library."""
import argparse
import os
from pathlib import Path
import subprocess
import tempfile
import zipfile

parser = argparse.ArgumentParser()
parser.add_argument('out', type=Path)
parser.add_argument('--sdk', type=Path, help='Android SDK on a desktop build host')
parser.add_argument('--android-tools', type=Path, help='Existing on-device ECJ and dx')
args = parser.parse_args()
if bool(args.sdk) == bool(args.android_tools):
    parser.error('supply exactly one of --sdk or --android-tools')
source = Path(__file__).with_name('ThermalHook.java').resolve()
with tempfile.TemporaryDirectory() as folder:
    work = Path(folder)
    classes = work / 'classes'
    classes.mkdir()
    if args.sdk:
        android_jar = args.sdk / 'platforms/android-35/android.jar'
        d8 = args.sdk / 'build-tools/35.0.0/d8'
        subprocess.run(['javac', '--release', '8', '-classpath', str(android_jar),
                        '-d', str(classes), str(source)], check=True)
        subprocess.run([str(d8), '--lib', str(android_jar), '--min-api', '35', '--output', str(work),
                        *map(str, sorted(classes.rglob('*.class')))], check=True)
    else:
        tools = args.android_tools.resolve()
        ide = tools / 'javaide-1.4.5.apk'
        env = {k: v for k, v in os.environ.items() if k not in ('LD_LIBRARY_PATH', 'LD_PRELOAD')}
        def art(classpath, main, *argv):
            subprocess.run(['/system/bin/app_process', '-Xmx128m', '/system/bin', main,
                            *map(str, argv)], env=dict(env, CLASSPATH=str(classpath)), check=True)
        art(ide, 'org.eclipse.jdt.internal.compiler.batch.Main', '-1.7', '-bootclasspath',
            tools / 'android.jar', '-d', classes, source)
        jar = work / 'hook.jar'
        with zipfile.ZipFile(jar, 'w') as archive:
            for path in sorted(classes.rglob('*.class')):
                archive.write(path, path.relative_to(classes))
        art(f'{tools / "dx-driver.dex"}:{ide}', 'BuildDx', '--dex',
            '--output=' + str(work / 'classes.dex'), jar)
    dex = (work / 'classes.dex').read_bytes()
    if not dex.startswith(b'dex\n') or b'Lorg/poagp/zygisk/ThermalHook;' not in dex:
        raise SystemExit('unexpected DEX output')
    args.out.parent.mkdir(parents=True, exist_ok=True)
    with args.out.open('w') as header:
        header.write('#pragma once\nstatic constexpr unsigned char kHookDex[] = {\n')
        for start in range(0, len(dex), 16):
            header.write('    ' + ', '.join(f'0x{b:02x}' for b in dex[start:start + 16]) + ',\n')
        header.write('};\n')
    print(f'Compiled ThermalHook.java to DEX ({len(dex)} bytes)')
