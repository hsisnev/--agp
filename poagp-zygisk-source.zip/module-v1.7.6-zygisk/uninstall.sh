#!/system/bin/sh
MODDIR=${0%/*}
/system/bin/sh "$MODDIR/agp-bypass.sh" off || exit 1
/system/bin/sh "$MODDIR/control.sh" stop
