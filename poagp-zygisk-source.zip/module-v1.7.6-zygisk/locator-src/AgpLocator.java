package agp;

import java.io.*;
import java.security.MessageDigest;
import java.util.*;

/** Read-only, bounded ELF64/AArch64 locator. No process access or memory writes.
 * Recognizes one auditable family of compiler layouts; unknown code is rejected.
 * Output is data, never shell code. PT_LOAD translates virtual to file addresses.
 */
public final class AgpLocator {
    static final String PREFIX = "_ZN3AGP14GameSdkManager";
    static final String GET = PREFIX + "11GetInstanceEv";
    static final String SET = PREFIX + "31SetGameSdkFeatureEnableInBattleEb";
    static final String CHECK = PREFIX + "34CheckGameIsInBattleForForceFeatureERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEE";
    static final long LIMIT = 1L << 40;
    byte[] b;
    final List<long[]> loads = new ArrayList<long[]>(); // offset, vaddr, filesz, memsz, flags
    final Map<String,long[]> symbols = new HashMap<String,long[]>();
    final Map<Long,String> relocs = new HashMap<Long,String>();
    long anchor = -1;

    static void need(boolean ok, String why) throws IOException {
        if (!ok) throw new IOException(why);
    }
    long u(long p, int n) throws IOException {
        need(p >= 0 && n > 0 && p <= b.length - n, "ELF 数据越界");
        long v = 0;
        for (int i=0;i<n;i++) v |= (b[(int)p+i] & 255L) << (8*i);
        need(n != 8 || v >= 0, "ELF 地址超出范围");
        return v;
    }
    void range(long p, long n) throws IOException {
        need(p >= 0 && n >= 0 && p <= b.length && n <= b.length-p, "ELF 表格越界");
    }
    String string(long p, long end) throws IOException {
        need(p >= 0 && end <= b.length && p < end, "ELF 字符串越界");
        int q=(int)p;
        while (q<end && q-p<1024 && b[q]!=0) q++;
        need(q<end && q-p<1024, "ELF 字符串未结束");
        return new String(b,(int)p,q-(int)p,"UTF-8");
    }
    AgpLocator(String path) throws Exception {
        File f=new File(path);
        need(f.length()>=64 && f.length()<=32*1024*1024, "库文件大小不支持");
        b=new byte[(int)f.length()];
        DataInputStream in=new DataInputStream(new FileInputStream(f));
        try { in.readFully(b); } finally { in.close(); }
        need(u(0,4)==0x464c457fL && u(4,1)==2 && u(5,1)==1 && u(6,1)==1 &&
             u(16,2)==3 && u(18,2)==183, "仅支持 ARM64 小端共享库");
        long ph=u(32,8), sh=u(40,8);
        int ps=(int)u(54,2), pn=(int)u(56,2), ss=(int)u(58,2), sn=(int)u(60,2);
        need(ps>=56 && pn>0 && pn<=128 && ss>=64 && sn>0 && sn<=8192, "ELF 表格格式不支持");
        range(ph,(long)ps*pn); range(sh,(long)ss*sn);
        for (int i=0;i<pn;i++) {
            long p=ph+(long)i*ps;
            if (u(p,4)!=1) continue;
            long off=u(p+8,8), va=u(p+16,8), fs=u(p+32,8), ms=u(p+40,8), flags=u(p+4,4);
            range(off,fs);
            need(fs<=ms && va<LIMIT && ms<LIMIT-va, "PT_LOAD 范围错误");
            loads.add(new long[]{off,va,fs,ms,flags});
            if (off==0 && fs>=64) { need(anchor<0 && va%4096==0,"库映射锚点不唯一"); anchor=va; }
        }
        need(anchor>=0,"没有库映射锚点");
        long[][] sections=new long[sn][];
        for(int i=0;i<sn;i++) {
            long p=sh+(long)i*ss;
            sections[i]=new long[]{u(p+4,4),u(p+24,8),u(p+32,8),u(p+40,4),u(p+56,8)};
            if(sections[i][0]!=8) range(sections[i][1],sections[i][2]);
        }
        for(int i=0;i<sn;i++) {
            long[] s=sections[i];
            if(s[0]!=11 && s[0]!=2) continue;
            need(s[3]<sn && s[4]>=24 && s[2]%s[4]==0 && s[2]/s[4]<=500000,"符号表格式不支持");
            long[] str=sections[(int)s[3]];
            need(str[0]==3,"符号字符串表错误");
            List<String> names=new ArrayList<String>();
            for(long j=0;j<s[2];j+=s[4]) {
                long p=s[1]+j, name=u(p,4);
                need(name<str[2],"符号名称越界");
                String n=string(str[1]+name,str[1]+str[2]); names.add(n);
                if(u(p+6,2)==0 || (u(p+4,1)&15)!=2) continue;
                long va=u(p+8,8), size=u(p+16,8);
                long[] old=symbols.get(n);
                need(old==null || (old[0]==va && old[1]==size),"存在同名不同地址符号");
                symbols.put(n,new long[]{va,size});
            }
            for(long[] r:sections) {
                if(r[0]!=4 || r[3]!=i) continue;
                need(r[4]>=24 && r[2]%r[4]==0 && r[2]/r[4]<=500000,"重定位表错误");
                for(long j=0;j<r[2];j+=r[4]) {
                    long p=r[1]+j, info=u(p+8,8), idx=info>>>32;
                    need(idx<names.size(),"重定位符号越界");
                    if((info&0xffffffffL)==1026) relocs.put(u(p,8),names.get((int)idx));
                }
            }
        }
    }
    long offset(long va, long size, int flags) throws IOException {
        long result=-1;
        for(long[] p:loads) if((p[4]&flags)==flags && va>=p[1] && size<=p[2] && va-p[1]<=p[2]-size) {
            need(result<0,"PT_LOAD 地址重叠"); result=p[0]+va-p[1];
        }
        need(result>=0,"目标指令不在文件代码段"); return result;
    }
    long word(long pc) throws IOException { return u(offset(pc,4,1),4); }
    long[] function(String name) throws IOException {
        long[] s=symbols.get(name);
        need(s!=null,"缺少定位符号："+name);
        need(s[0]%4==0 && s[1]>=8 && s[1]<=4096 && s[1]%4==0,"函数范围不支持");
        offset(s[0],s[1],1); return s;
    }
    static int rd(long w) {return (int)(w&31);}
    static int rn(long w) {return (int)((w>>>5)&31);}
    static int rm(long w) {return (int)((w>>>16)&31);}
    static long sx(long v,int bits) {return (v<<(64-bits))>>(64-bits);}
    static boolean adrp(long w) {return (w&0x9f000000L)==0x90000000L;}
    static boolean add(long w) {return (w&0xffc00000L)==0x91000000L;}
    static boolean mov(long w) {return (w&0x7fe0ffe0L)==0x2a0003e0L;}
    static boolean bl(long w) {return (w&0xfc000000L)==0x94000000L;}
    static boolean branch(long w) {return (w&0xfc000000L)==0x14000000L;}
    static boolean harmless(long w) {
        // Stack-only integer pair saves/restores, frame setup, BTI/PAC, NOP.
        return (((w&0x3e000000L)==0x28000000L) && (w&0x04000000L)==0 && rn(w)==31) ||
            (((w&0xffc00000L)==0xf9000000L || (w&0xffc00000L)==0xf9400000L) && rn(w)==31) ||
            w==0x910003fdL || w==0xd503201fL || w==0xd503233fL || w==0xd50323bfL ||
            w==0xd503245fL || w==0xd503249fL;
    }
    long page(long pc,long w) {return (pc&~4095L)+(sx(((w>>>5)&0x7ffff)*4+((w>>>29)&3),21)<<12);}
    long pair(long pc) throws IOException {
        long w=word(pc), z=word(pc+4);
        need(adrp(w) && add(z) && rn(z)==rd(w) && rd(z)==rd(w),"地址指令对不匹配");
        return page(pc,w)+((z>>>10)&4095);
    }
    String call(long pc) throws IOException {
        long w=word(pc); need(bl(w),"不是调用指令");
        long target=pc+sx(w&0x3ffffff,26)*4;
        for(Map.Entry<String,long[]> e:symbols.entrySet()) if(e.getValue()[0]==target) return e.getKey();
        long a=word(target), l=word(target+4), d=word(target+8), br=word(target+12);
        need(adrp(a) && rd(a)==16 && (l&0xffc003ffL)==0xf9400211L &&
            add(d) && rd(d)==16 && rn(d)==16 && br==0xd61f0220L,"调用跳板不支持");
        long slot=page(target,a)+((l>>>10)&4095)*8;
        need(((d>>>10)&4095)==((l>>>10)&4095)*8,"调用跳板地址不一致");
        String n=relocs.get(slot); need(n!=null,"无法确认调用目标"); return n;
    }
    long[] getter(long[] f) throws IOException {
        long object=-1, guard=-1, ret=-1, test=-1;
        for(long pc=f[0];pc<f[0]+f[1];pc+=4) {
            long w=word(pc);
            if(harmless(w)) {
                boolean load=(w&0x3e400000L)==0x28400000L || (w&0xffc00000L)==0xf9400000L;
                need(!load || (rd(w)>=19 && ((w&0x3e000000L)!=0x28000000L || ((w>>>10)&31)>=19)),
                    "单例返回寄存器可能被栈覆盖");
                continue;
            }
            if(adrp(w)) {
                long addr=pair(pc); int reg=rd(w); pc+=4;
                long next=word(pc+4);
                if((next&0xfffffc00L)==0x08dffc00L && rn(next)==reg) {
                    long tbz=word(pc+8);
                    need((tbz&0xfff80000L)==0x36000000L && rd(tbz)==rd(next),"初始化检查不是 bit0 TBZ");
                    need(guard<0,"初始化标志不唯一"); guard=addr;
                    test=pc+8+sx((tbz>>>5)&0x3fff,14)*4;
                    pc+=8;
                } else {need(reg==0 && object<0,"返回对象地址不唯一"); object=addr;}
                continue;
            }
            if(w==0xd65f03c0L) {ret=pc;break;}
            throw new IOException("单例快速路径结构不支持");
        }
        need(object>=0 && guard>=0 && ret>=0 && test>ret && test<f[0]+f[1],"单例/初始化标志定位失败");
        int acquire=0,release=0,ctor=0;
        for(long pc=ret+4;pc<f[0]+f[1];pc+=4) if(bl(word(pc))) {
            String name=call(pc);
            if(name.startsWith("__cxa_guard_")) {
                need(pc>=f[0]+8 && pair(pc-8)==guard && rd(word(pc-8))==0,"初始化调用地址不一致");
                if(name.equals("__cxa_guard_acquire")) {need(test==pc-8,"初始化慢路径入口不匹配");acquire++;}
                if(name.equals("__cxa_guard_release")) release++;
            }
            if(name.equals(PREFIX+"C1Ev") || name.equals(PREFIX+"C2Ev")) {
                need(pair(pc-8)==object && rd(word(pc-8))==0,"构造对象地址不一致"); ctor++;
            }
        }
        need(acquire==1 && release==1 && ctor==1,"单例构造/初始化调用不一致");
        return new long[]{object,guard};
    }
    static final class Regs {
        int[] k=new int[32]; long[] v=new long[32]; // 0 unknown, 1 this+offset, 2 bool, 3 constant
        void clobber(){for(int i=0;i<19;i++)k[i]=0;}
        void copy(int d,int s,boolean wide){k[d]=k[s];v[d]=v[s];if(!wide && k[d]==1)k[d]=0;}
    }
    void restoreRegs(Regs r,long w) {
        if((w&0x3e400000L)==0x28400000L && rn(w)==31) {r.k[rd(w)]=0; r.k[(int)((w>>>10)&31)]=0;}
        if((w&0xffc00000L)==0xf9400000L && rn(w)==31) r.k[rd(w)]=0;
    }
    long setter(long[] f) throws IOException {
        Regs r=new Regs();r.k[0]=1;r.k[1]=2;long field=-1; boolean returned=false;
        for(long pc=f[0];pc<f[0]+f[1];pc+=4) {
            long w=word(pc);int d=rd(w),n=rn(w);
            if(harmless(w)){restoreRegs(r,w);continue;}
            if(mov(w)){r.copy(d,rm(w),(w&0x80000000L)!=0);continue;}
            if(add(w) && r.k[n]==1){r.k[d]=1;r.v[d]=r.v[n]+((w>>>10)&4095);continue;}
            if(bl(w)) {
                String name=call(pc);
                need(name.equals("pthread_mutex_lock") || name.equals("pthread_mutex_unlock"),"开关函数包含未知调用");
                r.clobber();continue;
            }
            if((w&0xffc00000L)==0x39000000L) {
                need(field<0 && r.k[n]==1 && r.k[d]==2,"开关写入来源不唯一或不是 bool 参数");
                field=r.v[n]+((w>>>10)&4095); continue;
            }
            if(w==0xd65f03c0L){returned=true;break;}
            throw new IOException("开关写入函数结构不支持");
        }
        need(returned && field>=0 && field<=4095,"开关成员定位失败");return field;
    }
    void checker(long[] f,long field) throws IOException {
        Regs r=new Regs();r.k[0]=1;long disabled=-1;int loaded=-1;
        for(long pc=f[0];pc<f[0]+f[1];pc+=4) {
            long w=word(pc);
            if(harmless(w)){restoreRegs(r,w);continue;}
            if(mov(w)){r.copy(rd(w),rm(w),(w&0x80000000L)!=0);continue;}
            if((w&0xffc00000L)==0x39400000L && r.k[rn(w)]==1) {
                need(r.v[rn(w)]+((w>>>10)&4095)==field,"读取与写入成员不一致");loaded=rd(w);
                long cmp=word(pc+4), br=word(pc+8);
                need(cmp==(0x7100041fL|((long)loaded<<5)) && (br&0xff00001fL)==0x54000001L,
                    "开关关闭分支含义不匹配");
                disabled=pc+8+sx((br>>>5)&0x7ffff,19)*4;break;
            }
            throw new IOException("开关读取函数结构不支持");
        }
        need(loaded>=0 && disabled>=f[0] && disabled<f[0]+f[1],"关闭分支定位失败");
        r=new Regs();boolean returned=false;
        Set<Long> visited=new HashSet<Long>();
        for(long pc=disabled;pc<f[0]+f[1];pc+=4) {
            need(pc>=f[0] && visited.add(pc),"关闭分支存在循环/越界");
            long w=word(pc);int d=rd(w),n=rn(w);
            if(harmless(w)){restoreRegs(r,w);continue;}
            if((w&0xffe00000L)==0x52800000L){r.k[d]=3;r.v[d]=(w>>>5)&0xffff;continue;}
            if(mov(w)){r.copy(d,rm(w),(w&0x80000000L)!=0);continue;}
            if(adrp(w)){r.k[d]=3;r.v[d]=page(pc,w);continue;}
            if(add(w)){r.v[d]=r.v[n]+((w>>>10)&4095);r.k[d]=r.k[n]==3?3:0;continue;}
            if(branch(w)){pc+=sx(w&0x3ffffff,26)*4-4;continue;}
            if(bl(w)){need(call(pc).equals("__android_log_print"),"关闭分支包含未知调用");r.clobber();continue;}
            if(w==0xd65f03c0L){need(r.k[0]==3 && r.v[0]==1,"关闭分支没有返回允许值1");returned=true;break;}
            throw new IOException("关闭分支结构不支持");
        }
        need(returned,"关闭分支没有结束");
    }
    static String digest(byte[] bytes,int off,int n) throws Exception {
        MessageDigest md=MessageDigest.getInstance("SHA-256");md.update(bytes,off,n);
        StringBuilder s=new StringBuilder();for(byte v:md.digest())s.append(String.format(Locale.US,"%02x",v&255));return s.toString();
    }
    String locate() throws Exception {
        long[] get=function(GET),set=function(SET),check=function(CHECK);
        long[] obj=getter(get);long member=setter(set);checker(check,member);
        long flag=obj[0]+member,guard=obj[1]; long[] data=null;
        for(long[] p:loads) if((p[4]&3)==2 && obj[0]>=p[1] && flag>=p[1] && flag<p[1]+p[3] &&
            guard>=p[1] && guard+8<=p[1]+p[3]) {need(data==null,"数据段不唯一");data=p;}
        need(data!=null && guard%8==0 && (flag<guard || flag>=guard+8),"目标不在同一可写非执行数据段");
        StringBuilder out=new StringBuilder("AGPLOC1 "+digest(b,0,b.length)+" auto\n");
        out.append(flag+" "+guard+" "+anchor+" "+data[1]+" "+(data[1]+data[3])+"\n");
        for(long[] f:new long[][]{get,set,check})out.append(f[0]+" "+f[1]+" "+digest(b,(int)offset(f[0],f[1],1),(int)f[1])+"\n");
        return out.toString();
    }
    public static void main(String[] args) {
        try {need(args.length==1,"用法：AgpLocator libagp.so");System.out.print(new AgpLocator(args[0]).locate());}
        catch(Exception e){System.err.println("AGP 自动定位失败："+e.getMessage());System.exit(1);}
    }
}
