"""Compile locator DEX with the existing, hash-verified local Android toolchain."""
from pathlib import Path
import hashlib
import os
import subprocess

BASE = Path(__file__).resolve().parents[1]
TOOLS = BASE.parent / 'module-v1.6.8/build-tools'
APK = TOOLS / 'javaide-1.4.5.apk'
assert hashlib.sha256(APK.read_bytes()).hexdigest() == '434e9f3ecd83f38e0d9473a804605a8402c9187fbb4bd5c6b81aad0682041644'
classes = BASE / 'build-tools/locator-classes'
classes.mkdir(parents=True, exist_ok=True)
env = {k: v for k, v in os.environ.items() if k not in ('LD_LIBRARY_PATH', 'LD_PRELOAD')}

def art(cp, main, *args):
    subprocess.run(['/system/bin/app_process', '-Xmx128m', '/system/bin', main, *args],
                   env=dict(env, CLASSPATH=str(cp)), check=True)

art(APK, 'org.eclipse.jdt.internal.compiler.batch.Main', '-1.7', '-bootclasspath',
    str(TOOLS / 'android.jar'), '-d', str(classes), str(BASE / 'locator-src/AgpLocator.java'))
out = BASE / 'build-tools/locator.new.dex'
art(str(TOOLS / 'dx-driver.dex') + ':' + str(APK), 'BuildDx', '--dex', '--output=' + str(out), str(classes))
assert out.read_bytes().startswith(b'dex\n')
out.replace(BASE / 'agp-locator.dex')
print('Built', BASE / 'agp-locator.dex')
