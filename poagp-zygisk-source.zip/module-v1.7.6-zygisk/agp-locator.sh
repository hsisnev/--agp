#!/system/bin/sh
# Profiles are validated data. Never source/eval output from the ELF parser.
agp_fail() { AGP_ERROR=$1; echo "$AGP_ERROR" >&2; return 1; }
agp_profile_valid() {
    [ -f "$1" ] && [ ! -L "$1" ] && [ "$(stat -c %s "$1")" -le 4096 ] || return 1
    awk -v hash="$2" '
        function dec(s) { return s ~ /^[0-9]+$/ && length(s)<=13 && s+0<1099511627776 }
        function sha(s) { return length(s)==64 && s !~ /[^0-9a-f]/ }
        NR==1 {if(NF!=3 || $1!="AGPLOC1" || $2!=hash || !sha($2) || ($3!="auto" && $3!="known")) bad=1}
        NR==2 {
            if(NF!=5) bad=1
            for(i=1;i<=5;i++) if(!dec($i)) bad=1
            if($4>=$5 || $1<$4 || $1>=$5 || $2<$4 || $2+8>$5 || $2%8 ||
               ($1>=$2 && $1<$2+8) || $3%4096) bad=1
        }
        NR>=3 && NR<=5 {
            if(NF!=3 || !dec($1) || !dec($2) || $1%4 || $2%4 || $2<8 || $2>4096 || !sha($3)) bad=1
            start[NR]=$1; stop[NR]=$1+$2
            for(i=3;i<NR;i++) if(start[NR]<stop[i] && start[i]<stop[NR]) bad=1
        }
        NR>5 {bad=1}
        END {exit bad || NR!=5}' "$1"
}
agp_load_profile() {
    agp_profile_valid "$1" "$AGP_HASH" || return 1
    {
        read -r agp_magic agp_h AGP_PROFILE_KIND &&
        read -r AGP_FLAG_RVA AGP_GUARD_RVA AGP_ANCHOR AGP_DATA_LO AGP_DATA_HI &&
        read -r AGP_CODE1 AGP_LEN1 AGP_SIG1 &&
        read -r AGP_CODE2 AGP_LEN2 AGP_SIG2 &&
        read -r AGP_CODE3 AGP_LEN3 AGP_SIG3
    } < "$1" || return 1
    AGP_PROFILE=$1
}
agp_locator_exec() (
    unset LD_LIBRARY_PATH LD_PRELOAD
    export CLASSPATH="$BASE/agp-locator.dex"
    set -- /system/bin/app_process -Xmx64m /system/bin agp.AgpLocator "$AGP_LIB"
    if [ ! -r /apex/com.android.art/lib64/libnativeloader.so ] &&
       [ ! -r /apex/com.android.runtime/lib64/libnativeloader.so ] &&
       [ ! -r /system/lib64/libnativeloader.so ] && [ -x /system/bin/nsenter ]; then
        for agp_ns_pid in $(pidof system_server 2>/dev/null); do
            case "$agp_ns_pid" in ''|*[!0-9]*) continue;; esac
            # Reuse only the mount view, preserving the current credentials/domain.
            if [ -r "/proc/$agp_ns_pid/root/apex/com.android.art/lib64/libnativeloader.so" ] ||
               [ -r "/proc/$agp_ns_pid/root/apex/com.android.runtime/lib64/libnativeloader.so" ]; then
                set -- /system/bin/nsenter -t "$agp_ns_pid" -m -- "$@"
                break
            fi
        done
    fi
    exec /system/bin/timeout 12 "$@"
)
agp_resolve() {
    AGP_ERROR=
    [ -r "$AGP_LIB" ] || { agp_fail '没有可读的 libagp.so；此策略无法定位'; return 1; }
    agp_sum=$(sha256sum "$AGP_LIB" 2>/dev/null) || { agp_fail '无法读取 AGP 库指纹'; return 1; }
    AGP_HASH=${agp_sum%% *}
    if [ -n "${AGP_PROFILE:-}" ] && agp_load_profile "$AGP_PROFILE"; then return 0; fi
    agp_known="$BASE/agp-profiles/$AGP_HASH.profile"
    if agp_load_profile "$agp_known"; then return 0; fi
    [ ! -L "$AGP_ROOT" ] && mkdir -p "$AGP_ROOT" && chmod 0700 "$AGP_ROOT" &&
        [ "$(stat -c %u "$AGP_ROOT")" = 0 ] || { agp_fail '无法创建定位记录目录'; return 1; }
    agp_cache="$AGP_ROOT/profiles-v1"
    [ ! -L "$agp_cache" ] && mkdir -p "$agp_cache" && chmod 0700 "$agp_cache" &&
        [ "$(stat -c %u "$agp_cache")" = 0 ] || { agp_fail '无法创建定位缓存'; return 1; }
    agp_cached="$agp_cache/$AGP_HASH.profile"
    if agp_load_profile "$agp_cached"; then return 0; fi
    [ -r "$BASE/agp-locator.dex" ] || { agp_fail '缺少自动定位程序，请重新安装完整模块'; return 1; }
    agp_tmp=$(mktemp "$agp_cache/.locate.XXXXXXXX") || return 1
    agp_locator_exec > "$agp_tmp" 2> "$agp_tmp.err"
    agp_loc_result=$?
    if [ "$agp_loc_result" != 0 ] || ! agp_profile_valid "$agp_tmp" "$AGP_HASH"; then
        agp_reason=$(head -c 1024 "$agp_tmp.err" | tr '\r\n\t' '   ')
        rm -f "$agp_tmp" "$agp_tmp.err"
        [ "$agp_loc_result" != 124 ] || agp_reason='定位超时，稍后重试'
        agp_fail "自动定位未通过：${agp_reason:-输出格式或库指纹不一致}"
        return 1
    fi
    rm -f "$agp_tmp.err"
    mv -f "$agp_tmp" "$agp_cached" && agp_load_profile "$agp_cached" || {
        agp_fail '无法保存定位结果'; return 1;
    }
}
