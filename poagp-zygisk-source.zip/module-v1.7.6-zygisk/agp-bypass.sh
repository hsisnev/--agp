#!/system/bin/sh
PATH=/system/bin:/system/xbin
export PATH
umask 077
BASE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
AGP_ROOT=/data/adb/honor185-agp-bypass
[ "$(id -u)" = 0 ] || { echo '需要现有Root身份；不会自行提权' >&2; exit 1; }
. "$BASE/agp-core.sh"
. "$BASE/agp-guard.sh"
. "$BASE/aps-shield.sh"
. "$BASE/thermal90-hook.sh"

agp_setup() {
    [ ! -L "$AGP_ROOT" ] || return 1
    mkdir -p "$AGP_ROOT" && chmod 0700 "$AGP_ROOT" || return 1
    [ "$(stat -c %u "$AGP_ROOT")" = 0 ]
}
agp_valid_job() {
    case "$1" in "$AGP_ROOT"/session.*) ;; *) return 1;; esac
    case "${1##*/}" in *[!A-Za-z0-9._-]*) return 1;; esac
    [ -d "$1" ] && [ ! -L "$1" ]
}
case "${1:-status}" in
locate)
    agp_resolve || exit 1
    echo "定位通过：$AGP_PROFILE_KIND；hash=$AGP_HASH；flagRVA=$AGP_FLAG_RVA guardRVA=$AGP_GUARD_RVA；未访问进程内存"
    ;;
inspect)
    agp_identity || exit 1
    echo "AGP PID=$AGP_PID flag=$(agp_read "$(agp_mem_path)" "$AGP_ADDR" 1 -tu1)；只读校验通过"
    echo "定位=$AGP_PROFILE_KIND hash=$AGP_HASH flagRVA=$AGP_FLAG_RVA guardRVA=$AGP_GUARD_RVA"
    ;;
status)
    [ -f "$BASE/agp-battle-bypass.on" ] || { echo '已关闭'; exit 0; }
    [ -f "$AGP_ROOT/latest" ] || { echo '已开启，等待名单内游戏'; exit 0; }
    IFS= read -r agp_latest < "$AGP_ROOT/latest"
    agp_valid_job "$AGP_ROOT/$agp_latest" || exit 1
    cat "$AGP_ROOT/$agp_latest/status" 2>/dev/null || echo '等待策略程序就绪'
    ;;
aps-status)
    [ -f "$BASE/aps-shield.on" ] || { echo '已关闭'; exit 0; }
    aps_shield_supported || { echo '此固件尚未验证 APS 接口'; exit 0; }
    [ -f "$BASE/agp-battle-bypass.on" ] || { echo '需同时开启解除 60Hz 限制'; exit 0; }
    [ -f "$AGP_ROOT/latest" ] || { echo '等待名单内游戏'; exit 0; }
    IFS= read -r agp_latest < "$AGP_ROOT/latest"
    agp_valid_job "$AGP_ROOT/$agp_latest" || exit 1
    cat "$AGP_ROOT/$agp_latest/aps.status" 2>/dev/null || echo '等待游戏和 AGP 校验'
    ;;
aps-off)
    rm -f "$BASE/aps-shield.on" || exit 1
    [ -d "$AGP_ROOT" ] || exit 0
    agp_setup || exit 1
    aps_result=0
    for agp_job in "$AGP_ROOT"/session.*; do
        agp_valid_job "$agp_job" || continue
        aps_shield_restore "$agp_job" || aps_result=1
    done
    [ "$aps_result" = 0 ] || { echo 'APS 恢复尚未确认，已保留记录' >&2; exit 1; }
    ;;
thermal90-status)
    [ -f "$BASE/thermal90-hook.on" ] || { echo '已关闭'; exit 0; }
    thermal90_supported || { echo '此固件的 90 限制尚未验证'; exit 0; }
    thermal90_installed || { echo '等待 Zygisk 加载，请检查 Zygisk 并重启'; exit 0; }
    [ -f "$BASE/agp-battle-bypass.on" ] || { echo '需同时开启解除 60Hz 限制'; exit 0; }
    [ -f "$AGP_ROOT/latest" ] || { echo '等待名单内游戏'; exit 0; }
    IFS= read -r agp_latest < "$AGP_ROOT/latest"
    agp_valid_job "$AGP_ROOT/$agp_latest" || exit 1
    thermal90_show_status "$AGP_ROOT/$agp_latest"
    ;;
thermal90-off)
    rm -f "$BASE/thermal90-hook.on" || exit 1
    thermal90_clear || exit 1
    ;;
restore|off)
    [ "$1" != off ] || rm -f "$BASE/agp-battle-bypass.on"
    thermal90_clear || :
    [ -d "$AGP_ROOT" ] || { echo '没有待恢复的记录'; exit 0; }
    agp_setup || exit 1
    agp_result=0
    for agp_job in "$AGP_ROOT"/session.*; do
        agp_valid_job "$agp_job" || continue
        if [ -f "$agp_job/restored" ] && [ ! -f "$agp_job/aps.before" ]; then continue; fi
        touch "$agp_job/cancel" || { agp_result=1; continue; }
        aps_shield_restore "$agp_job" || agp_result=1
        agp_restore "$agp_job" || agp_result=1
    done
    [ "$agp_result" = 0 ] || { echo '游戏策略恢复未完成，已保留记录' >&2; exit 1; }
    echo '非战斗限制绕过已恢复'
    ;;
_guard)
    agp_setup && agp_valid_job "$2" || exit 1
    exec 9> "$AGP_ROOT/session.lock" || exit 1
    flock -n 9 9>&9 || { touch "$2/busy"; exit 1; }
    # Complete a previous interrupted session before replacing its journal.
    for agp_old_job in "$AGP_ROOT"/session.*; do
        [ "$agp_old_job" != "$2" ] || continue
        agp_valid_job "$agp_old_job" || continue
        if [ -f "$agp_old_job/restored" ] && [ ! -f "$agp_old_job/aps.before" ]; then continue; fi
        touch "$agp_old_job/cancel" || exit 1
        aps_shield_restore "$agp_old_job" || touch "$2/aps.recovery-pending"
        agp_restore "$agp_old_job" || { touch "$2/failed"; exit 1; }
    done
    echo "${2##*/}" > "$AGP_ROOT/latest.tmp.$$" && mv -f "$AGP_ROOT/latest.tmp.$$" "$AGP_ROOT/latest" || exit 1
    agp_guard "$2"
    ;;
*) echo '用法：agp-bypass.sh locate | inspect | status | off | restore | aps-status | aps-off' >&2; exit 2;;
esac
